module.exports = {
    /**
     * @description 基础url
     */
    BASE_URL_API: process.env.NODE_ENV === 'production' ? '/' : '/api/',
    /**
     * @description token在Cookie中存储的天数，默认1天
     */
    CookieExpires: 1,
    /**
     * @description token key
     */
    TokenKey: 'TOKEN',
    /**
     * @description token key
     */
    UserKey: 'USER',
    /**
     * 侧边栏主题 深色主题theme-dark，浅色主题theme-light
     */
    sideTheme: 'theme-dark',
    /**
     * 是否系统布局配置
     */
    showSettings: false,

    /**
     * 是否显示顶部导航
     */
    topNav: false,

    /**
     * 是否显示 tagsView
     */
    tagsView: true,

    /**
     * 是否显示面包屑
     */
    showBreadcrumb: true,

    /**
     * 是否固定头部
     */
    fixedHeader: false,

    /**
     * 是否显示logo
     */
    sidebarLogo: true,

    /**
     * 是否显示动态标题
     */
    dynamicTitle: false,

    /**
     * 是否显示折叠按钮
     */
    showFold: true,

    /**
     * @description 请求超时时间，毫秒（默认1小时）
     */
    timeout: 1000*60*60,

}
