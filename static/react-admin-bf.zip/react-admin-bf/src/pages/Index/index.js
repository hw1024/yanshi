import React from 'react';
import {renderRoutes} from 'react-router-config'
import {Layout, Icon} from 'antd';
import HeaderBar from '@/components/HeaderBar';
import SiderNav from '@/components/SiderNav';

const {Header, Content, Sider} = Layout;

class Index extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            route: props.route.routes,
            collapsed: false
        };
    }

    toggle = () => {
        this.setState((prevState) => ({collapsed: !prevState.collapsed}));
    }

    render() {
        return (
            <Layout>
                <Sider
                    collapsed={this.state.collapsed}
                    style={{
                        overflow: 'auto',
                        height: '100vh',
                        left: 0,
                    }}
                >
                    <div className="logo"/>
                    <SiderNav collapsed={this.state.collapsed}></SiderNav>
                </Sider>
                <Layout style={{height: '100vh'}}>
                    <Header style={{background: '#fff', padding: 0, position:"relative"}}>
                        <Icon
                            className="trigger"
                            style={{
                                position: 'absolute',
                                left: '20px',
                                top: '20px',
                                'font-size': '24px',
                            }}
                            type={this.state.collapsed ? 'menu-unfold' : 'menu-fold'}
                            onClick={this.toggle}
                        />
                        <HeaderBar></HeaderBar>
                    </Header>
                    <Content style={{margin: '24px 16px 0', overflow: 'initial'}}>
                        {renderRoutes(this.state.route)}
                    </Content>
                </Layout>
            </Layout>
        );
    }
}

export default Index;
