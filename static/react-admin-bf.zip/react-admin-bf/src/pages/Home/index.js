import React, { Component } from 'react';
import style from './index.scss';

export default class Home extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div className={style.guideContainer}>
				home
			</div>
		);
	}
}
