import React from 'react';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import {Form, Input, Checkbox, Button} from 'antd';
import {userLogin, getCodeImg, getInfo} from '@/api/passport';
import {getRouters} from '@/api/menu';
import {listData} from '@/api/system/dict/data';
import {login, getUserInfo, getMenu, getDictData, getPermissions} from '@/redux/actions/userStore';
import {encrypt, decrypt} from '@/utils/jsencrypt';
import {getCookie, setCookie, removeCookie} from '@/utils/cookie';
import userIcon from '@/common/images/icon-user.png';
import passwordIcon from '@/common/images/icon-code.png';
import captchaIcon from '@/common/images/icon-captcha.png';

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            codeUrl: '',
            uuid: '',
        };
    }

    componentDidMount() {
        if (this.props.userStore.isLogin) {
            this.props.history.push({pathname: '/'});
        }
        this.getCode();
        this.getCookie();
    }

    getCode() {
        getCodeImg().then(res => {
            this.captchaEnabled = res.captchaEnabled === undefined ? true : res.captchaEnabled;
            if (this.captchaEnabled) {
                this.setState(() => ({
                    codeUrl: "data:image/gif;base64," + res.img,
                    uuid: res.uuid,
                }));
            }
        });
    }

    getCookie() {
        const {form} = this.props;
        const username = getCookie('username');
        const password = getCookie('password');
        const remember = getCookie('remember');
        form.setFieldsValue({
            username: username === undefined ? this.state.username : username,
            password: password === undefined ? this.state.password : decrypt(password),
            remember: remember === undefined ? false : Boolean(remember)
        });
    }

    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                if (values.remember) {
                    setCookie('username', values.username);
                    setCookie('password', encrypt(values.password));
                    setCookie('remember', values.remember);
                } else {
                    removeCookie('username');
                    removeCookie('password');
                    removeCookie('remember');
                }
                values.uuid = this.state.uuid
                userLogin(values).then((response) => {
                    if (response.code === 200) {
                        this.props.login(response);
                        getInfo().then((data) => {
                            this.props.getDictData(data.user);
                            this.props.getPermissions(data.permissions);
                            listData({
                                pageNum: 1,
                                pageSize: 10000
                            }).then((dict) => {
                                this.props.getUserInfo(dict.rows);
                                if (dict.code === 200) {
                                    getRouters().then((res) => {
                                        this.props.getMenu(res.data);
                                        if (res.code === 200) {
                                            let {from} = this.props.location.state || {from: {pathname: '/'}};
                                            this.props.history.push(from);
                                        }
                                    });
                                }
                            })
                        })
                    } else {
                        this.getCode();
                    }
                }).catch(()=> {
                    this.getCode();
                });
            }
        });
    };

    render() {
        let {getFieldDecorator} = this.props.form;
        let {codeUrl} = this.state;
        return (
            <div className="passport-container">
                <div className="passport-box">
                    <div className="passport-form">
                        <div className="passport-logo">react-ant-admin</div>
                        <Form
                            name="login_form"
                            className="ant-form"
                            onSubmit={this.handleSubmit}
                            labelCol={{span: 0}}
                            wrapperCol={{span: 24}}
                            autoComplete="off"
                        >
                            <Form.Item
                                label=""
                            >
                                {
                                    getFieldDecorator('username', {
                                        rules: [{required: true, message: '请输入账号'}]
                                    })(
                                        <Input allowClear placeholder="账号"
                                            prefix={<img src={userIcon} style={{width: '16px'}}
                                                         alt="user"/>}/>
                                    )
                                }
                            </Form.Item>
                            <Form.Item
                                label=""
                            >
                                {
                                    getFieldDecorator('password', {
                                        rules: [{required: true, message: '请输入密码'}]
                                    })(
                                        <Input allowClear placeholder="密码"
                                               prefix={<img src={passwordIcon} style={{width: '16px'}}
                                                            alt="user"/>}/>
                                    )
                                }
                            </Form.Item>
                            <Form.Item
                                label=""
                                className="form-item-code"
                            >
                                {
                                    getFieldDecorator('code', {
                                        rules: [{required: true, message: '请输入验证码'}]
                                    })(
                                        <Input allowClear placeholder="验证码"
                                               prefix={<img src={captchaIcon} style={{width: '16px'}}
                                                            alt="captcha"/>}/>
                                    )
                                }
                                <div className="login-code">
                                    <img src={codeUrl} onClick={() => this.getCode()} className="login-code-img" alt='codeUrl'/>
                                </div>
                            </Form.Item>
                            <Form.Item
                                name="remember"
                            >
                                <div className="passport-flex">
                                    <div className="passport-checkbox">
                                        {getFieldDecorator('remember', {
                                            valuePropName: 'checked',
                                        })(<Checkbox/>)}
                                        <span className="passport-checkbox-text">自动登录</span>
                                    </div>
                                </div>
                            </Form.Item>
                            <Form.Item>
                                <Button type="primary" htmlType="submit">登录</Button>
                            </Form.Item>
                        </Form>
                    </div>
                </div>
            </div>
        );
    }
}

let mapStateToProps = (state) => ({
    userStore: state.userStore
});

let mapDispatchToProps = (dispatch) => ({
    login(username) {
        dispatch(login(username));
    },
    getUserInfo(info) {
        dispatch(getUserInfo(info));
    },
    getDictData(dictData) {
        dispatch(getDictData(dictData));
    },
    getPermissions(permissions) {
        dispatch(getPermissions(permissions));
    },
    getMenu(menu) {
        dispatch(getMenu(menu));
    },
});

export default Form.create({name: 'login_form'})(withRouter(connect(mapStateToProps, mapDispatchToProps)(Login)));
