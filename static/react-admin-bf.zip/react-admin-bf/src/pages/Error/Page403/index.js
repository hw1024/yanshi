import React, { Component } from 'react';
import { Result, Button } from 'antd';

export default class Page403 extends Component {
	constructor(props) {
		super(props);
	}
	goBack() {
		this.props.history.push({pathname: '/'});
	}
	render() {
		return (
			<div>
				<Result
					status="403"
					title="403"
					subTitle="Sorry, you are not authorized to access this page."
					extra={<Button onClick={() => this.goBack()} type="primary">Back Home</Button>}
				/>
			</div>
		);
	}
}
