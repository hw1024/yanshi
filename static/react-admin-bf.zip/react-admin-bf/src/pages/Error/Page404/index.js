import React, { Component } from 'react';
import { Result, Button } from 'antd';

export default class Page404 extends Component {
	constructor(props) {
		super(props);
	}
	goBack() {
		this.props.history.push({pathname: '/'});
	}
	render() {
		return (
			<div>
				<Result
					status="404"
					title="404"
					subTitle="Sorry, the page you visited does not exist."
					extra={<Button onClick={() => this.goBack()} type="primary">Back Home</Button>}
				/>
			</div>
		);
	}
}
