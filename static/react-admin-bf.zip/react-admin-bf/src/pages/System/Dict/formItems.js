import React from 'react'
import {Select, DatePicker} from 'antd'
const {RangePicker} = DatePicker;
import {getDictData} from '@/utils/common'

const Option = Select.Option
const dateFormat = 'YYYY/MM/DD';

const selectExample = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_normal_disable').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

const rangePickerTemp = (
    <RangePicker format={dateFormat} />
)

export default [
    {
        label: '字典名称',
        placeholder: '请输入字典名称',
        key: 'dictName',
        required: false,
    },
    {
        label: '字典类型',
        key: 'dictType',
        placeholder: '请输入字典类型',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectExample,
    },
    {
        label: '创建时间',
        key: 'params',
        required: false,
        component: rangePickerTemp,
    },
]
