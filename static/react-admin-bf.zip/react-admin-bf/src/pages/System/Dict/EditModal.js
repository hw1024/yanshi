import React, {Component} from 'react';
import {Modal, Form, Input, Radio} from 'antd';

const {TextArea} = Input;

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            dictName: Form.createFormField({
                ...props.dictName,
                value: props.formData.dictName
            }),
            dictType: Form.createFormField({
                ...props.dictName,
                value: props.formData.dictType
            }),
            status: Form.createFormField({
                ...props.dictName,
                value: props.formData.status
            }),
            remark: Form.createFormField({
                ...props.dictName,
                value: props.formData.remark
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        const {setFieldsValue} = this.props.form;
        setFieldsValue({
            dictName: "dictName"
        })
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return; //检查Form表单填写的数据是否满足rules的要求
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data); //调用父组件给的onOk方法并传入Form的参数。
        })
    };

    onCancel = () => {
        this.props.form.resetFields(); //重置Form表单的内容
        this.props.onCancel() //调用父组件给的方法
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="dict_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="字典名称"
                    >
                        {
                            getFieldDecorator('dictName', {
                                rules: [{required: true, message: '字典名称不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入字典名称"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="字典类型"
                    >
                        {
                            getFieldDecorator('dictType', {
                                rules: [{required: true, message: '字典类型不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入字典类型"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="状态"
                    >
                        {
                            getFieldDecorator('status', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择角色状态'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="备注"
                    >
                        {
                            getFieldDecorator('remark')(
                                <TextArea rows={4} placeholder="请输入备注"/>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
