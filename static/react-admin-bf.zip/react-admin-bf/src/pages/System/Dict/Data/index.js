import React, {Component} from 'react';
import {listData, delData, getData, updateData, addData} from '@/api/system/dict/data';
import {getType} from "@/api/system/dict/type";
import {Button, Divider, message, Modal, Table, Pagination} from "antd";
import DttForm from '@/components/DttForm';
import formItems from './formItems';
import {download} from '@/utils/request';
import EditModal from './EditModal';

function showTotal(total) {
    return `共 ${total} 条`;
}

export default class DictData extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            total: 0,
            ids: [],
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            },
            defaultDictType: '',
            dataList: null,
            visible: false,
            formData: null,
            modalTitle: '编辑字典数据',
        };
        this.columns = [
            {
                title: '字典编码',
                dataIndex: 'dictCode',
                dictCode: 'dictCode',
                key: 'dictCode',
                width: '180px',
            },
            {
                title: '字典标签',
                dataIndex: 'dictLabel',
                key: 'dictLabel',
                width: '130px',
            },
            {
                title: '字典键值',
                dataIndex: 'dictValue',
                width: '100px',
                key: 'dictValue ',
            },
            {
                title: '字典排序',
                dataIndex: 'dictSort',
                key: 'dictSort',
            },
            {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (text) => (
                    <span>{text + '' === '0' ? "正常" : "停用"}</span>
                ),
            },
            {
                title: '备注',
                dataIndex: 'remark',
                key: 'remark',
            },
            {
                title: '创建时间',
                key: 'createTime',
                dataIndex: 'createTime',
            },
            {
                title: '操作',
                key: 'action',
                width: '190px',
                render: (text) => (
                    <span className="dtt-cell-operations">
                        <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                        <Divider type="vertical"/>
                        <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                    </span>
                ),
            },
        ];
    }

    componentDidMount() {
        const dictId = this.props.location.state.id;
        this.getType(dictId);
    }

    getType(dictId) {
        let data = this.state.queryParams;
        getType(dictId).then(response => {
            data.dictType = response.data.dictType;
            this.setState({
                queryParams: data,
                defaultDictType: response.data.dictType,
            });
            this.getList();
        });
    }

    getList() {
        listData(this.state.queryParams).then(res => {
            this.setState({
                dataList: res.rows,
                total: res.total
            })
        });
    }


    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let params = {...this.state.queryParams, ...values}
            listData(params).then(res => {
                this.setState({
                    dataList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleAdd() {
        this.setState({
            visible: true,
            formData: {dictType: this.state.queryParams.dictType, status: '0'},
            modalTitle: '添加字典数据'
        });
    }

    handleUpdate(row) {
        const dictCode = row.dictCode
        getData(dictCode).then(response => {
            this.setState({
                visible: true,
                formData: response.data,
                modalTitle: '修改字典类型'
            });
        });
    }


    handleOk = (data) => {
        let methods = data.dictCode ? updateData : addData;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    routeLink = (row, data) => {
        console.log(row, data)
        let route = '/system/dict-data/index/' + data.dictId
        this.props.history.push(route);
    }

    /** 删除按钮操作 */
    handleDelete = (row) => {
        const dictCodes = row.dictCode || this.state.ids;
        if (dictCodes.length === 0) {
            message.warning("请选择要删除的数据！");
            return false
        }
        Modal.confirm({
            title: '',
            content: '是否确认删除字典编号为"' + dictCodes + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: () => {
                delData(dictCodes).then(() => {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    }

    handleExport = () => {
        download('system/dict/data/export', {
            ...this.state.queryParams
        }, `dict_data_${new Date().getTime()}.xlsx`)
    };

    render() {
        let {dataList, total, queryParams, visible, modalTitle, formData} = this.state;
        const columns = this.columns;
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.dictCode)
                })
            },
        };
        return (
            <>
                <div className="dtt-search data">
                    <DttForm ref={this.formRef} items={formItems}/>
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{marginLeft: 8}} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button type="primary" onClick={this.handleAdd.bind(this)} icon="plus">新增</Button>
                    <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                    <Button icon="download" onClick={this.handleExport}>导出</Button>
                </div>
                <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={dataList}
                       pagination={false} rowKey='dictCode'/>
                <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize} hideOnSinglePage
                            current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                            onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
                <EditModal
                    visible={visible}
                    title={modalTitle}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />
            </>
        );
    }
}
