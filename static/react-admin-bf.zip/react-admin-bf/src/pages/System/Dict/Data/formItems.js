import React from 'react'
import {Select} from 'antd'

const Option = Select.Option

const selectExample = (
    <Select allowClear placeholder='请选择状态'>
        {
            [{dictValue: '0', dictLabel: '正常'}, {dictValue: '1', dictLabel: '停用'}].map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

export default [
    {
        label: '字典标签',
        placeholder: '请输入字典标签',
        key: 'dictLabel',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectExample,
    },
]
