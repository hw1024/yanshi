import React, {Component} from 'react';
import {listMenu, delMenu, addMenu, updateMenu, getMenu} from '@/api/system/menu';
import DttForm from '@/components/DttForm';
import formItems from './formItems';
import EditModal from './EditModal';
import {Button, Divider, message, Modal, Table, Icon} from "antd";
import {handleTree} from '@/utils/common';

export default class Menu extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            isExpandAll: false,
            menuList: null,
            visible: false,
            formData: null,
            modalTitle: '修改菜单',
            treeData: [],
        };
        this.menuColumns = [
            {
                title: '菜单名称',
                dataIndex: 'menuName',
                menu: 'menu',
                key: 'menuName',
                width: '180px',
            },
            {
                title: '图标',
                dataIndex: 'icon',
                key: 'icon',
                width: '130px',
            },
            {
                title: '排序',
                dataIndex: 'orderNum',
                width: '100px',
                key: 'orderNum',
            },
            {
                title: '权限标识',
                dataIndex: 'perms',
                key: 'perms',
            },
            {
                title: '组件路径',
                dataIndex: 'component',
                key: 'component',
            },
            {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (text) => (
                    <span>{text + '' === '0' ? "正常" : "停用"}</span>
                ),
            },
            {
                title: '创建时间',
                key: 'createTime',
                dataIndex: 'createTime',
            },
            {
                title: '操作',
                key: 'action',
                width: '250px',
                render: (text) => (
                    <span className="dtt-cell-operations">
                        <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                        <Divider type="vertical"/>
                        <Button type="link" icon="plus" onClick={this.handleAdd.bind(this, text)}>新增</Button>
                        <Divider type="vertical"/>
                        <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                    </span>
                ),
            },
        ];
    }

    componentDidMount() {
        this.getList();
        this.getMenuOptions();
    }

    getList() {
        listMenu().then(res => {
            this.setState({
                menuList: handleTree(res.data, "menuId")
            })
            console.log(this.state.menuList)
        });
    }

    getMenuOptions() {
        listMenu().then(response => {
            let menuOptions = response.data;
            menuOptions.forEach(item => {
                item.key = item.menuId
                item.value = item.menuId
                item.title = item.menuName
            })
            let treeData = handleTree(menuOptions, "menuId");
            this.menuEditModal.updateTreeData(treeData, 'add');
        });
    }

    onRef = (ref) => {
        this.menuEditModal = ref
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let params = {...this.state.queryParams, ...values}
            listMenu(params).then(res => {
                this.setState({
                    menuList: handleTree(res.data, "menuId")
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    handleAdd(row) {
        if (row != null && row.menuId) {
            row.menuValue = row.menuId
            this.menuEditModal.updateSelectTree(row);
        } else {
            this.menuEditModal.updateSelectTree();
        }
        this.setState({
            visible: true,
            formData: row ? {parentId: row.menuId, menuType: 'M', visible: '0', isFrame: '1', isCache: '0', status: '0', orderNum: 0} : null,
            modalTitle: '新增菜单'
        });
    }

    handleUpdate = (row) => {
        const menuId = row.menuId
        getMenu(menuId).then(response => {
            row.menuValue = response.data.parentId +'' === '0' ? '' : response.data.parentId;
            this.menuEditModal.updateSelectTree(row);
            this.setState({
                visible: true,
                formData: response.data,
                modalTitle: '修改菜单'
            });
        });
    }

    handleOk = (data) => {
        let methods = data.menuId ? updateMenu : addMenu;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getMenuOptions();
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    toggleExpandAll = () => {
        this.setState((state) => ({isExpandAll: !state.isExpandAll}));
    }

    /** 删除按钮操作 */
    handleDelete(row) {
        Modal.confirm({
            title: '',
            content: '是否确认删除名称为"' + row.menuName + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: () => {
                delMenu(row.menuId).then(() => {
                    this.getList();
                    this.getMenuOptions();
                    message.success("删除成功");
                })
            },
        });
    }

    render() {
        const columns = this.menuColumns;
        let {menuList, isExpandAll, visible, modalTitle, treeData, formData} = this.state;
        return (
            <>
                <div className="dtt-search menu">
                    <DttForm ref={this.formRef} items={formItems} />
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button type="primary" onClick={this.handleAdd.bind(this)} icon="plus">新增</Button>
                    <Button type="default" onClick={this.toggleExpandAll} icon="swap">展开/折叠</Button>
                </div>
                <Table className="dtt-table" expandIcon={({expanded, onExpand, record}) => {
                    if (expanded) {
                        return <Icon type="down" onClick={e => onExpand(record, e)}/>
                    } else {
                        return <Icon type="right" onClick={e => onExpand(record, e)}/>
                    }
                }} key={isExpandAll} columns={columns} dataSource={menuList} defaultExpandAllRows={isExpandAll}
                       pagination={false} rowKey='menuId'/>
                <EditModal
                    onRef={this.onRef}
                    visible={visible}
                    title={modalTitle}
                    treeData={treeData}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />
            </>
        );
    }
}
