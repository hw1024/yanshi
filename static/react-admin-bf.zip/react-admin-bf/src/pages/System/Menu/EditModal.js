import React, {Component} from 'react';
import {Modal, Row, Col, Form, Input, Radio, InputNumber, TreeSelect} from 'antd';

const defaultFormItemLayout = {
    labelCol: { style: { width: '88px', display: 'inline-block', 'vertical-align': 'inherit' } },
    wrapperCol: { style: {width: 'calc(100% - 88px)', display: 'inline-block'} }
}

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            orderNum: Form.createFormField({
                ...props.menuName,
                value: props.formData.orderNum
            }),
            parentId: Form.createFormField({
                ...props.menuName,
                value: props.formData.parentId
            }),
            isFrame: Form.createFormField({
                ...props.menuName,
                value: props.formData.isFrame
            }),
            icon: Form.createFormField({
                ...props.menuName,
                value: props.formData.icon
            }),
            path: Form.createFormField({
                ...props.menuName,
                value: props.formData.path
            }),
            menuName: Form.createFormField({
                ...props.menuName,
                value: props.formData.menuName
            }),
            menuType : Form.createFormField({
                ...props.menuName,
                value: props.formData.menuType
            }),
            component: Form.createFormField({
                ...props.menuName,
                value: props.formData.component
            }),
            isCache: Form.createFormField({
                ...props.menuName,
                value: props.formData.isCache
            }),
            query: Form.createFormField({
                ...props.menuName,
                value: props.formData.query
            }),
            perms: Form.createFormField({
                ...props.menuName,
                value: props.formData.perms
            }),
            status: Form.createFormField({
                ...props.menuName,
                value: props.formData.status
            }),
            visible: Form.createFormField({
                ...props.menuName,
                value: props.formData.visible
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showIsCache: true,
            showVisible: true,
            showStatus: true,
            showPath: true,
            showIsFrame: true,
            showQuery: true,
            showComponent: true,
            showPerms: true,
            treeData: [],
            treeDefaultExpandAll: false
        }
    }

    componentDidMount() {
        this.props.onRef(this)
    }

    updateTreeData = (data, type) => {
        this.setState({
            treeData: data,
        });
    }

    updateSelectTree = (data) =>{
        this.menuTypeChange(data ? data.menuType : '')
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return; //检查Form表单填写的数据是否满足rules的要求
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data); //调用父组件给的onOk方法并传入Form的参数。
        })
    };

    onCancel = () => {
        this.props.form.resetFields(); //重置Form表单的内容
        this.props.onCancel() //调用父组件给的方法
    };

    menuTypeChange = e => {
        let value = e.target ? e.target.value : e;
        console.log(value)
        this.setState({
            showStatus: value+ '' !== 'F',
            showVisible: value+ '' !== 'F',
            showPath: value+ '' !== 'F',
            showIsFrame: value+ '' !== 'F',
            showIsCache: value+ '' === 'C',
            showQuery: value+ '' === 'C',
            showComponent: value+ '' === 'C',
            showPerms: value+ '' !== 'M',
        });
    }

    render() {
        const {layout} = this.props;
        const {getFieldDecorator} = this.props.form;
        const {showStatus, showVisible, showIsCache, showPath, showIsFrame, showQuery, showComponent, showPerms} = this.state
        return (
            <Modal
                onOk={this.onOk}
                width="680px"
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >

                <Row>
                    <Form
                        name="dict_form"
                        className="ant-form"
                        onSubmit={this.handleSubmit}
                        labelCol={{span: 4}}
                        wrapperCol={{span: 20}}
                        autoComplete="off"
                    >
                        <Col span={24}>
                            <Form.Item
                                label="上级菜单"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('parentId')(
                                        <TreeSelect
                                            style={{width: '100%'}}
                                            dropdownStyle={{maxHeight: 400, overflow: 'auto'}}
                                            placeholder="请选择上级部门"
                                            treeDefaultExpandAll={this.state.treeDefaultExpandAll}
                                            treeData={this.state.treeData}
                                        />
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <Form.Item
                                label="菜单类型"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('menuType', {
                                        initialValue: 'M',
                                        rules: [{required: true, message: '请选择菜单类型'}]
                                    })(
                                        <Radio.Group onChange={this.menuTypeChange}>
                                            <Radio value={'M'}>目录</Radio>
                                            <Radio value={'C'}>菜单</Radio>
                                            <Radio value={'F'}>按钮</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <Form.Item
                                label="菜单图标"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('icon')(
                                        <Input allowClear placeholder="请输入菜单图标"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="菜单名称"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('menuName', {
                                        rules: [{required: true, message: '菜单名称不能为空'}]
                                    })(
                                        <Input allowClear placeholder="请输入菜单名称"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="显示排序"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('orderNum', {
                                        initialValue: 0,
                                        rules: [{required: true, message: '显示排序不能为空'}]
                                    })(
                                        <InputNumber className="from-input-number" min={0} max={9999} allowClear
                                                     placeholder=""/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        {showIsFrame && <Col span={12}>
                            <Form.Item
                                label="是否外链"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('isFrame', {
                                        initialValue: '1',
                                        rules: [{required: true, message: '请选择是否外链'}]
                                    })(
                                        <Radio.Group>
                                            <Radio value={'0'}>是</Radio>
                                            <Radio value={'1'}>否</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showPath && <Col span={12}>
                            <Form.Item
                                label="路由地址"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('path', {
                                        rules: [{required: true, message: '路由地址不能为空'}]
                                    })(
                                        <Input allowClear placeholder="请输入路由地址"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showComponent && <Col span={12}>
                            <Form.Item
                                label="组件路径"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('component', {
                                        rules: [{required: true, message: '组件路径不能为空'}]
                                    })(
                                        <Input allowClear placeholder="请输入组件路径"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showPerms && <Col span={12}>
                            <Form.Item
                                label="权限标识"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('perms')(
                                        <Input allowClear placeholder="请输入权限标识"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showQuery && <Col span={12}>
                            <Form.Item
                                label="路由参数"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('query')(
                                        <Input allowClear placeholder="请输入路由参数"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showIsCache &&
                        <Col span={12}>
                            <Form.Item
                                label="是否缓存"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('isCache', {
                                        initialValue: '0'
                                    })(
                                        <Radio.Group>
                                            <Radio value={'0'}>是</Radio>
                                            <Radio value={'1'}>否</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showVisible && <Col span={12}>
                            <Form.Item
                                label="显示状态"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('visible', {
                                        initialValue: '0'
                                    })(
                                        <Radio.Group>
                                            <Radio value={'0'}>正常</Radio>
                                            <Radio value={'1'}>停用</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {showStatus && <Col span={12}>
                            <Form.Item
                                label="菜单状态"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('status', {
                                        initialValue: '0'
                                    })(
                                        <Radio.Group>
                                            <Radio value={'0'}>正常</Radio>
                                            <Radio value={'1'}>停用</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                    </Form>
                </Row>
            </Modal>
        )
    }
}

EditModal.defaultProps = {
    layout: defaultFormItemLayout,
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
