import React, {Component} from 'react';
import {Modal, Form, Input, TreeSelect, InputNumber, Radio} from 'antd';

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            deptName: Form.createFormField({
                ...props.deptName,
                value: props.formData.deptName
            }),
            parentId: Form.createFormField({
                ...props.deptName,
                value: props.formData.parentId
            }),
            orderNum: Form.createFormField({
                ...props.deptName,
                value: props.formData.orderNum
            }),
            leader: Form.createFormField({
                ...props.deptName,
                value: props.formData.leader
            }),
            phone: Form.createFormField({
                ...props.deptName,
                value: props.formData.phone
            }),
            status: Form.createFormField({
                ...props.deptName,
                value: props.formData.status
            }),
            email: Form.createFormField({
                ...props.deptName,
                value: props.formData.email
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            treeData: [],
            value: undefined,
            treeDefaultExpandAll: false
        }
    }

    componentDidMount() {
        this.props.onRef(this)
    }

    updateTreeData = (data) => {
        this.setState({
            treeData: data,
        });
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return; //检查Form表单填写的数据是否满足rules的要求
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data); //调用父组件给的onOk方法并传入Form的参数。
        })
    };

    onCancel = () => {
        this.props.form.resetFields(); //重置Form表单的内容
        this.props.onCancel() //调用父组件给的方法
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="dept_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="上级部门"
                    >
                        {
                            getFieldDecorator('parentId', {
                                rules: [{required: true, message: '上级部门不能为空'}]
                            })(
                                <TreeSelect
                                    style={{width: '100%'}}
                                    dropdownStyle={{maxHeight: 400, overflow: 'auto'}}
                                    placeholder="请选择上级部门"
                                    treeDefaultExpandAll={this.state.treeDefaultExpandAll}
                                    treeData={this.state.treeData}
                                />
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="部门名称"
                    >
                        {
                            getFieldDecorator('deptName', {
                                rules: [{required: true, message: '部门名称不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入部门名称"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="显示排序"
                    >
                        {
                            getFieldDecorator('orderNum', {
                                initialValue: 0,
                                rules: [{required: true, message: '显示排序不能为空'}]
                            })(
                                <InputNumber className="from-input-number" min={0} max={9999} allowClear
                                             placeholder=""/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="负责人"
                    >
                        {
                            getFieldDecorator('leader')(
                                <Input allowClear placeholder="请输入负责人"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="联系电话"
                    >
                        {
                            getFieldDecorator('phone')(
                                <Input allowClear placeholder="请输入联系电话"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="邮箱"
                    >
                        {
                            getFieldDecorator('email', {rules: [
                                {
                                    pattern: /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/,
                                    message: '邮箱格式不正确',
                                },
                                {
                                    max: 50,
                                    message: '邮箱不得超过50字符',
                                },
                            ]})(
                                <Input allowClear placeholder="请输入邮箱"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="状态"
                    >
                        {
                            getFieldDecorator('status', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择部门状态'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
