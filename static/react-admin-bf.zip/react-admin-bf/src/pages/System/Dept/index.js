import React, {Component} from 'react';
import {listDept, delDept, addDept, updateDept, getDept} from '@/api/system/dept';
import DttForm from '@/components/DttForm';
import {handleTree, filterDictData} from '@/utils/common';
import formItems from './formItems';
import EditModal from './EditModal';
import {Button, Divider, message, Modal, Table, Icon} from "antd";

export default class Dept extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            deptList: null,
            isExpandAll: false,
            visible: false,
            formData: null,
            modalTitle: '修改部门',
            treeData: [],
        };
        this.columns = [
            {
                title: '部门名称',
                dataIndex: 'deptName',
                key: 'deptName',
                width: '260px',
            },
            {
                title: '排序',
                dataIndex: 'orderNum',
                key: 'orderNum',
                width: '200px',
            },
            {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: (text) => (
                    <span>{filterDictData('sys_normal_disable', text)}</span>
                ),
            },
            {
                title: '创建时间',
                key: 'createTime',
                dataIndex: 'createTime',
            },
            {
                title: '操作',
                key: 'action',
                width: '250px',
                render: (text) => (
                    <span className="dtt-cell-operations">
                        <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                        <Divider type="vertical"/>
                        <Button type="link" icon="plus" onClick={this.handleAdd.bind(this, text)}>新增</Button>
                        {text.parentId + '' !== '0' && <><Divider type="vertical"/><Button type="link" icon="delete"
                                                                                           onClick={this.handleDelete.bind(this, text)}>删除</Button></>}
                    </span>
                ),
            },
        ];
    }

    componentDidMount() {
        this.getList();
        this.getDeptOptions();
    }

    getList() {
        listDept().then(res => {
            this.setState({
                deptList: handleTree(res.data, "deptId")
            })
        });
    }

    getDeptOptions() {
        listDept().then(response => {
            let deptOptions = response.data;
            deptOptions.forEach(item => {
                item.key = item.deptId
                item.value = item.deptId
                item.title = item.deptName
            })
            let treeData = handleTree(deptOptions, "deptId");
            this.deptEditModal.updateTreeData(treeData, 'add');
        });
    }

    onRef = (ref) => {
        this.deptEditModal = ref
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let params = {...this.state.queryParams, ...values}
            listDept(params).then(res => {
                this.setState({
                    deptList: handleTree(res.data, "deptId")
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    handleAdd(row) {
        if (row !== undefined) {
            this.deptEditModal.updateSelectTree(row.deptId);
        }
        this.setState({
            visible: true,
            formData: row ? {parentId: row.deptId, status: '0', orderNum: 0} : null,
            modalTitle: '新增菜单'
        });
    }

    handleUpdate = (row) => {
        const dictId = row.deptId
        getDept(dictId).then(response => {
            this.setState({
                visible: true,
                formData: response.data,
                modalTitle: '修改菜单'
            });
        });
    }

    handleOk = (data) => {
        let methods = data.deptId ? updateDept : addDept;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getDeptOptions();
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    toggleExpandAll = () => {
        this.setState((state) => ({isExpandAll: !state.isExpandAll}));
    }

    /** 删除按钮操作 */
    handleDelete(row) {
        Modal.confirm({
            title: '',
            content: '是否确认删除名称为"' + row.deptName + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: () => {
                delDept(row.deptId).then(() => {
                    this.getList();
                    this.getDeptOptions();
                    message.success("删除成功");
                })
            },
        });
    }

    render() {
        let {deptList, isExpandAll, visible, treeData, modalTitle, formData} = this.state;
        const columns = this.columns;
        return (
            <>
                <div className="dtt-search">
                    <DttForm ref={this.formRef} items={formItems}/>
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{marginLeft: 8}} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button type="primary" onClick={this.handleAdd.bind(this)} icon="plus">新增</Button>
                    <Button type="default" onClick={this.toggleExpandAll} icon="swap">展开/折叠</Button>
                </div>
                <Table className="dtt-table" expandIcon={({expanded, onExpand, record}) => {
                    if (expanded) {
                        return <Icon type="down" onClick={e => onExpand(record, e)}/>
                    } else {
                        return <Icon type="right" onClick={e => onExpand(record, e)}/>
                    }
                }} key={isExpandAll} columns={columns} dataSource={deptList} defaultExpandAllRows={isExpandAll}
                       pagination={false} rowKey='deptId'/>
                <EditModal
                    onRef={this.onRef}
                    visible={visible}
                    title={modalTitle}
                    treeData={treeData}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />
            </>
        );
    }
}
