import React from 'react'
import {Select} from 'antd'
import {getDictData} from '@/utils/common'

const Option = Select.Option

const selectExample = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_normal_disable').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

export default [
    {
        label: '部门名称',
        placeholder: '请输入部门名称',
        key: 'deptName',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectExample,
    },
]
