import React from 'react'
import {Select} from 'antd'
import {getDictData} from '@/utils/common'
const Option = Select.Option

const selectTemp = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_normal_disable').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

export default [
    {
        label: '岗位编码',
        key: 'postCode',
        placeholder: '请输入岗位编码',
        required: false,
    },
    {
        label: '岗位名称',
        key: 'postName',
        placeholder: '请输入岗位名称',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectTemp,
    },
]
