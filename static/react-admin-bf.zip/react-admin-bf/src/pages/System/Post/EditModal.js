import React, {Component} from 'react';
import {Modal, Form, Input, InputNumber, Radio} from 'antd';

const {TextArea} = Input;

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            postName: Form.createFormField({
                ...props.postName,
                value: props.formData.postName
            }),
            status: Form.createFormField({
                ...props.postName,
                value: props.formData.status
            }),
            postSort: Form.createFormField({
                ...props.postName,
                value: props.formData.postSort
            }),
            postCode: Form.createFormField({
                ...props.postName,
                value: props.formData.postCode
            }),
            remark: Form.createFormField({
                ...props.postName,
                value: props.formData.remark
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return;
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data);
        })
    };

    onCancel = () => {
        this.props.form.resetFields();
        this.props.onCancel()
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="login_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="岗位名称"
                    >
                        {
                            getFieldDecorator('postName', {
                                rules: [{required: true, message: '岗位名称不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入岗位名称" alt="postName"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="岗位编码"
                    >
                        {
                            getFieldDecorator('postCode', {
                                rules: [{required: true, message: '岗位编码不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入岗位编码"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="岗位顺序"
                    >
                        {
                            getFieldDecorator('postSort', {
                                initialValue: 0,
                                rules: [{required: true, message: '岗位顺序不能为空'}]
                            })(
                                <InputNumber className="from-input-number" min={0} max={9999} allowClear
                                             placeholder=""/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="状态"
                    >
                        {
                            getFieldDecorator('status', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择岗位状态'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="备注"
                    >
                        {
                            getFieldDecorator('remark')(
                                <TextArea rows={4} placeholder="请输入备注"/>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
