import React, {Component} from 'react'
import {withRouter} from "react-router-dom";
import {Table, Divider, Button, Pagination, message, Modal } from 'antd';
import DttForm from '@/components/DttForm';
import {download} from '@/utils/request';
import {addDateRange, filterDictData} from "@/utils/common";
import formItems from './formItems';
import EditModal from './EditModal';
import {listPost, addPost, updatePost, delPost, getPost} from '@/api/system/post';

function showTotal(total) {
    return `共 ${total} 条`;
}

class Post extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            ids: [],
            postList: null,
            total: 0,
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            },
            visible: false,
            formData: null,
            modalTitle: '编辑岗位',
            columns: [
                {
                    title: '岗位编号',
                    dataIndex: 'postId',
                    width: '120',
                    key: 'postId',
                },
                {
                    title: '岗位编码',
                    dataIndex: 'postCode',
                    width: '150',
                    key: 'postCode',
                },
                {
                    title: '岗位名称',
                    dataIndex: 'postName',
                    width: '150',
                    key: 'postName',
                },
                {
                    title: '岗位排序',
                    dataIndex: 'postSort',
                    width: '100',
                    key: 'postSort',
                },
                {
                    title: '状态',
                    key: 'status',
                    width: '100',
                    dataIndex: 'status',
                    render: (text) => (
                        <span>{filterDictData('sys_common_status', text)}</span>
                    ),
                },
                {
                    title: '创建时间',
                    key: 'createTime',
                    dataIndex: 'createTime',
                },
                {
                    title: '操作',
                    key: 'action',
                    width: '190px',
                    render: (text) => (
                        <span className="dtt-cell-operations">
                            <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                            <Divider type="vertical"/>
                            <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                        </span>
                    ),
                },
            ]
        };
    }

    componentDidMount() {
        this.getList();
    }

    getList() {
        listPost(this.state.queryParams).then(res => {
            this.setState({
                postList: res.rows,
                total: res.total
            })
        });
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let data = addDateRange(values, values.params)
            let params = {...this.state.queryParams, ...data}
            listPost(params).then(res => {
                this.setState({
                    postList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    handleAdd = () => {
        this.setState({
            visible: true,
            formData: null,
            modalTitle: '添加岗位'
        });
    };

    handleUpdate = (row) => {
        const postId = row.postId
        getPost(postId).then(response => {
            let data = response.data
            this.setState({
                visible: true,
                formData:data,
                modalTitle: '修改岗位'
            });
        });
    }
    handleDelete = (row) => {
        const postIds = row.postId || this.state.ids;
        if(postIds.length === 0) {
            message.warning("请选择要删除的数据！");
            return false
        }
        Modal.confirm({
            title: '',
            content: '是否确认删除岗位编号为"' + postIds + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: ()=> {
                delPost(postIds).then(()=> {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    };

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleExport = () => {
        download('system/post/export', {
            ...this.state.queryParams
        }, `post_${new Date().getTime()}.xlsx`)
    }

    handleOk = (data) => {
        let methods = data.postId ? updatePost : addPost;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    render() {
        let {postList, total, queryParams, visible, modalTitle, formData} = this.state;
        const columns = this.state.columns;
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.postId)
                })
            },
        };
        return (
            <>
                <div className="dtt-search">
                    <DttForm ref={this.formRef} items={formItems} />
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button icon="plus" type="primary" onClick={this.handleAdd.bind(this)}>新增</Button>
                    <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                    <Button icon="download" onClick={this.handleExport}>导出</Button>
                </div>
                <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={postList} pagination={false} rowKey='postId'/>
                <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize} hideOnSinglePage
                            current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                            onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
                <EditModal
                    visible={visible}
                    title={modalTitle}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />

            </>
        )
    }
}

export default withRouter((Post));
