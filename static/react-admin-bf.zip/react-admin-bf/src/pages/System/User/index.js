import React, {Component} from 'react'
import {withRouter} from "react-router-dom";
import {Row, Col, Table, Divider, Pagination, Button, Modal, message, Form, Switch, Tree, Input} from 'antd';
import DttForm from '@/components/DttForm';
import formItems from './formItems';
import {listUser, delUser, getUser, addUser, updateUser, changeUserStatus, deptTreeSelect} from '@/api/system/consumer';
import {download} from '@/utils/request';
import {addDateRange} from "@/utils/common";
import EditModal from "./EditModal";

const {TreeNode} = Tree;
const {Search} = Input;

function showTotal(total) {
    return `共 ${total} 条`;
}

class User extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            ids: [],
            userList: null,
            expand: false,
            total: 0,
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            },
            deptId: '',
            visible: false,
            deptOptions: [],
            expandedKeys: [],
            searchValue: '',
            autoExpandParent: false,
            defaultExpandAll: true,
            formData: null,
            modalTitle: '编辑角色',
            postOptions: [],
            roleOptions: [],
            editType: 'add',
            columns: [
                {
                    title: '用户编号',
                    dataIndex: 'userId',
                    key: 'userId',
                },
                {
                    title: '用户名称',
                    dataIndex: 'userName',
                    key: 'userName',
                },
                {
                    title: '用户昵称',
                    dataIndex: 'nickName',
                    key: 'nickName',
                },
                {
                    title: '部门',
                    dataIndex: 'dept.deptName',
                    key: 'deptName',
                },
                {
                    title: '手机号码',
                    dataIndex: 'phonenumber',
                    key: 'phonenumber',
                },
                {
                    title: '状态',
                    key: 'status',
                    dataIndex: 'status',
                    render: (text, data) => (
                        <Switch checked={data.status + '' === '0'}
                                onChange={this.handleStatusChange.bind(this, text, data)}/>
                    ),

                },
                {
                    title: '创建时间',
                    key: 'createTime',
                    dataIndex: 'createTime',
                },
                {
                    title: '操作',
                    key: 'action',
                    width: '190px',
                    render: (text) => (
                        <span className="dtt-cell-operations">
                            <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                            <Divider type="vertical"/>
                            <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                        </span>
                    ),
                },
            ]
        };
    }

    componentDidMount() {
        this.getList();
        this.getDeptTree();
    }

    getList() {
        listUser(this.state.queryParams).then(res => {
            this.setState({
                userList: res.rows,
                total: res.total
            })
            console.log(res)
        });
    }

    getDeptTree() {
        deptTreeSelect().then(response => {
            let deptOptions = this.resetDeptTree(response.data);
            this.setState({
                deptOptions: deptOptions
            })
            this.userEditModal.updateSelectData({depts: deptOptions});
        });
    }

    resetDeptTree(data) {
        data.forEach((item) => {
            item.key = item.id
            item.value = item.id
            item.title = item.label
            if (item.children) {
                this.resetDeptTree(item.children);
            }
        });
        return data
    }

    handleSearch = (e) => {
        e && e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let data = addDateRange(values, values.params)
            let params = this.state.deptId !== '' ? {...this.state.queryParams, ...data, ...{deptId:this.state.deptId}} : {...this.state.queryParams, ...data}
            listUser(params).then(res => {
                this.setState({
                    userList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.setState({
            deptId: '',
        })
        this.getList();
    }

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleStatusChange = (row, data) => {
        let text = data.status === "1" ? "启用" : "停用";
        Modal.confirm({
            title: '',
            cancelText: '取消',
            className: 'dtt-confirm',
            content: '确认要"' + text + '""' + data.userName + '"用户吗？',
            okText: '确认',
            onOk: () => {
                data.status = data.status === "0" ? "1" : "0";
                changeUserStatus(data.userId, data.status).then(() => {
                    this.getList();
                    message.success(text + "成功");
                })
            },
        });
    }

    onRef = (ref) => {
        this.userEditModal = ref
    }

    handleAdd = () => {
        getUser().then(response => {
            let postsArr = response.posts
            let rolesArr = response.roles
            postsArr.forEach(item => {
                item.key = item.deptId
                item.value = item.deptId
                item.title = item.deptName
            })
            this.setState({
                visible: true,
                formData: null,
                postOptions: postsArr,
                roleOptions: rolesArr,
                modalTitle: '添加用户',
                editType: 'add'
            });
        })
    }

    handleUpdate = (row) => {
        const userId = row.userId
        getUser(userId).then(response => {
            let data = response.data
            data.postIds = response.postIds
            data.roleIds = response.roleIds
            let postsArr = response.posts
            let rolesArr = response.roles
            this.setState({
                visible: true,
                formData: data,
                postOptions: postsArr,
                roleOptions: rolesArr,
                modalTitle: '修改用户',
                editType: 'edit'
            });
        });
    }

    handleDelete = (row) => {
        const userIds = row.userId || this.state.ids;
        if (userIds.length === 0) {
            message.warning("请选择要删除的数据！");
            return false
        }
        Modal.confirm({
            title: '',
            content: '是否确认删除访问编号为"' + userIds + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: () => {
                delUser(userIds).then(() => {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    };

    handleExport = () => {
        download('/system/user/export', {
            ...this.state.queryParams
        }, `user_${new Date().getTime()}.xlsx`)
    };

    handleOk = (data) => {
        let methods = data.userId ? updateUser : addUser;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    onExpand = expandedKeys => {
        this.setState({
            expandedKeys,
            autoExpandParent: false,
        });
    };

    onSelect = (selectedKeys) => {
        this.setState({
            deptId: selectedKeys[0]
        })
        setTimeout(()=> {
            this.handleSearch()
        },10)
    };

    searchTreeChange = e => {
        const dataList = [];
        const generateList = data => {
            for (let i = 0; i < data.length; i++) {
                const node = data[i];
                const {label, id} = node;
                dataList.push({key: id, title: label});
                if (node.children) {
                    generateList(node.children);
                }
            }
        };
        generateList(this.state.deptOptions);
        const {value} = e.target;
        const expandedKeys = dataList.map(item => {
            console.log(this.getParentKey(item.key, this.state.deptOptions))
            if (item.title.indexOf(value) > -1) {
                return this.getParentKey(item.key, this.state.deptOptions);
            }
            return null;
        }).filter((item, i, self) => item && self.indexOf(item) === i);
        this.setState({
            expandedKeys,
            searchValue: value,
            autoExpandParent: true,
        });
    };

    getParentKey = (key, tree) => {
        let parentKey;
        for (let i = 0; i < tree.length; i++) {
            const node = tree[i];
            if (node.children) {
                if (node.children.some(item => item.id === key)) {
                    parentKey = node.key;
                } else if (this.getParentKey(key, node.children)) {
                    parentKey = this.getParentKey(key, node.children);
                }
            }
        }
        return parentKey;
    };

    render() {
        let {
            userList,
            total,
            queryParams,
            visible,
            modalTitle,
            postOptions,
            roleOptions,
            editType,
            formData,
            deptOptions,
            searchValue,
            expandedKeys,
            defaultExpandAll,
            autoExpandParent,
        } = this.state;
        const columns = this.state.columns;
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.userId)
                })
            },
        };
        const loop = data =>
            data.map(item => {
                const index = item.title.indexOf(searchValue);
                const beforeStr = item.title.substr(0, index);
                const afterStr = item.title.substr(index + searchValue.length);
                const title =
                    index > -1 ? (
                        <span>{beforeStr}
                            <span style={{color: '#f50'}}>{searchValue}</span>
                            {afterStr}</span>
                    ) : (
                        <span>{item.title}</span>
                    );
                if (item.children) {
                    return (
                        <TreeNode key={item.key} title={title}>
                            {loop(item.children)}
                        </TreeNode>
                    );
                }
                return <TreeNode key={item.key} title={title}/>;
            });
        return (
            <>
                <Row gutter={20}>
                    <Col xs={{span: 24}} lg={{span: 4}}>
                        <Search style={{marginBottom: 8}} placeholder="请输入部门名称" onChange={this.searchTreeChange}/>
                        <Tree
                            onExpand={this.onExpand}
                            expandedKeys={expandedKeys}
                            defaultExpandAll={defaultExpandAll}
                            autoExpandParent={autoExpandParent}
                            onSelect={this.onSelect}
                        >
                            {loop(deptOptions)}
                        </Tree>
                    </Col>
                    <Col xs={{span: 24}} lg={{span: 20}}>
                        <div className="dtt-search">
                            <DttForm ref={this.formRef} items={formItems}/>
                            <div className="dtt-search-operation">
                                <Button type="primary" onClick={this.handleSearch}>
                                    搜索
                                </Button>
                                <Button style={{marginLeft: 8}} onClick={this.handleReset}>
                                    重置
                                </Button>
                            </div>
                        </div>
                        <div className="dtt-operations">
                            <Button type="primary" icon="plus" onClick={this.handleAdd}>新增</Button>
                            <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                            <Button icon="download" onClick={this.handleExport}>导出</Button>
                        </div>
                        <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={userList}
                               pagination={false} rowKey='userId'/>
                        <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize}
                                    hideOnSinglePage
                                    current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                                    onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
                    </Col>
                </Row>
                <EditModal
                    onRef={this.onRef}
                    visible={visible}
                    editType={editType}
                    postOptions={postOptions}
                    roleOptions={roleOptions}
                    title={modalTitle}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />
            </>
        )
    }
}

export default Form.create({name: 'search_form'})(withRouter((User)));
