import React from 'react'
import {Select, DatePicker} from 'antd'
import {getDictData} from '@/utils/common'
const {RangePicker} = DatePicker;

const Option = Select.Option
const dateFormat = 'YYYY/MM/DD';

const selectExample = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_normal_disable').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

const rangePickerTemp = (
    <RangePicker format={dateFormat} />
)

export default [
    {
        label: '用户名称',
        placeholder: '请输入用户名称',
        key: 'userName',
        required: false,
    },
    {
        label: '手机号码',
        placeholder: '请输入手机号码',
        key: 'phonenumber',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectExample,
    },
    {
        label: '创建时间',
        key: 'params',
        required: false,
        component: rangePickerTemp,
    },
]
