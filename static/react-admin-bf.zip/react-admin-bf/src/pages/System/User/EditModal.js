import React, {Component} from 'react';
import {Modal, Form, Input, Select, Radio, TreeSelect, Col, Row} from 'antd';

const {TextArea} = Input;
const {Option} = Select;

const defaultFormItemLayout = {
    labelCol: {style: {width: '88px', display: 'inline-block', 'vertical-align': 'inherit'}},
    wrapperCol: {style: {width: 'calc(100% - 88px)', display: 'inline-block'}}
}

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            nickName: Form.createFormField({
                ...props.userName,
                value: props.formData.nickName
            }),
            deptId: Form.createFormField({
                ...props.userName,
                value: props.formData.deptId
            }),
            phonenumber: Form.createFormField({
                ...props.userName,
                value: props.formData.phonenumber
            }),
            email: Form.createFormField({
                ...props.userName,
                value: props.formData.email
            }),
            userName: Form.createFormField({
                ...props.userName,
                value: props.formData.userName
            }),
            sex: Form.createFormField({
                ...props.userName,
                value: props.formData.sex
            }),
            status: Form.createFormField({
                ...props.userName,
                value: props.formData.status
            }),
            password: Form.createFormField({
                ...props.userName,
                value: props.formData.password
            }),
            postIds: Form.createFormField({
                ...props.userName,
                value: props.formData.postIds
            }),
            roleIds: Form.createFormField({
                ...props.userName,
                value: props.formData.roleIds
            }),
            remark: Form.createFormField({
                ...props.userName,
                value: props.formData.remark
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            deptData: [],
            rolesData: [],
            treeDefaultExpandAll: false
        }
    }

    componentDidMount() {
        this.props.onRef(this)
    }

    updateSelectData = (data) => {
        this.setState({
            deptData: data.depts,
        });
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return;
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data); //调用父组件给的onOk方法并传入Form的参数。
        })
    };

    onCancel = () => {
        this.props.form.resetFields(); //重置Form表单的内容
        this.props.onCancel() //调用父组件给的方法
    };

    render() {
        const {layout, editType, postOptions, roleOptions} = this.props;
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                width="680px"
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Row>
                    <Form
                        name="login_form"
                        className="ant-form"
                        onSubmit={this.handleSubmit}
                        labelCol={{span: 4}}
                        wrapperCol={{span: 20}}
                        autoComplete="off"
                    >
                        <Col span={12}>
                            <Form.Item
                                label="用户昵称"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('nickName', {
                                        rules: [{required: true, message: '用户昵称不能为空'}]
                                    })(
                                        <Input allowClear placeholder="请输入用户昵称" alt="nickName"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="归属部门"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('deptId', {
                                        rules: [{required: true, message: '归属部门不能为空'}]
                                    })(
                                        <TreeSelect
                                            style={{width: '100%'}}
                                            dropdownStyle={{maxHeight: 400, overflow: 'auto'}}
                                            placeholder="请选择归属部门"
                                            treeDefaultExpandAll={this.state.treeDefaultExpandAll}
                                            treeData={this.state.deptData}
                                        />
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="手机号码"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('phonenumber', {
                                        rules: [{
                                            pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/,
                                            message: "请输入正确的手机号码",
                                            trigger: "blur"
                                        }]
                                    })(
                                        <Input allowClear placeholder="请输入手机号码"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="邮箱"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('email', {
                                        rules: [{required: true, message: '邮箱不能为空'}]
                                    })(
                                        <Input allowClear placeholder="请输入邮箱"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        {editType === 'add' && <Col span={12}>
                            <Form.Item
                                label="用户名称"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('userName', {
                                        rules: [{required: true, message: '用户名称不能为空'}, {
                                            min: 2,
                                            max: 20,
                                            message: '用户名称长度必须介于 2 和 20 之间',
                                            trigger: 'blur'
                                        }]
                                    })(
                                        <Input allowClear placeholder="请输入用户名称"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        {editType === 'add' && <Col span={12}>
                            <Form.Item
                                label="用户密码"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('password', {
                                        rules: [{required: true, message: '用户密码不能为空'}, {
                                            min: 5,
                                            max: 20,
                                            message: '用户密码长度必须介于 5 和 20 之间',
                                            trigger: 'blur'
                                        }]
                                    })(
                                        <Input.Password allowClear placeholder="请输入用户密码"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        }
                        <Col span={12}>
                            <Form.Item
                                label="用户性别"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('sex')(
                                        <Select allowClear placeholder="请输入用户性别">
                                            <Option value="0">男</Option>
                                            <Option value="1">女</Option>
                                            <Option value="2">未知</Option>
                                        </Select>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="状态"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('status', {
                                        initialValue: '0',
                                        rules: [{required: true, message: '请选择角色状态'}]
                                    })(
                                        <Radio.Group>
                                            <Radio value={'0'}>正常</Radio>
                                            <Radio value={'1'}>停用</Radio>
                                        </Radio.Group>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="岗位"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('postIds')(
                                        <Select allowClear mode="multiple" placeholder="请选择岗位">
                                            {
                                                postOptions.map((item) => {
                                                    return <Option value={item.postId}>{item.postName}</Option>
                                                })
                                            }
                                        </Select>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                label="角色"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('roleIds')(
                                        <Select allowClear mode="multiple" placeholder="请选择角色">
                                            {
                                                roleOptions.map((item) => {
                                                    return <Option value={item.roleId}>{item.roleName}</Option>
                                                })
                                            }
                                        </Select>
                                    )
                                }
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <Form.Item
                                label="备注"
                                {...layout}
                            >
                                {
                                    getFieldDecorator('remark')(
                                        <TextArea rows={4} placeholder="请输入备注"/>
                                    )
                                }
                            </Form.Item>
                        </Col>
                    </Form>
                </Row>
            </Modal>
        )
    }
}

EditModal.defaultProps = {
    layout: defaultFormItemLayout,
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
