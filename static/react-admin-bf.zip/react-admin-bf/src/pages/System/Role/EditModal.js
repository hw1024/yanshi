import React, {Component} from 'react';
import {Modal, Form, Input, InputNumber, Radio, Checkbox, Tree} from 'antd';

const {TextArea} = Input;
const {TreeNode} = Tree;
const CheckboxGroup = Checkbox.Group;

const defaultCheckedList = ['menuCheckStrictly'];

function mapPropsToFields(props) {
    console.log(props)
    if (props.formData) {
        return {
            roleName: Form.createFormField({
                ...props.roleName,
                value: props.formData.roleName
            }),
            roleKey: Form.createFormField({
                ...props.roleName,
                value: props.formData.roleKey
            }),
            roleSort: Form.createFormField({
                ...props.roleName,
                value: props.formData.roleSort
            }),
            status: Form.createFormField({
                ...props.roleName,
                value: props.formData.status
            }),
            remark: Form.createFormField({
                ...props.roleName,
                value: props.formData.remark
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            checkedList: defaultCheckedList,
            autoExpandParent: true,
            checkStrictly: true,
            defaultSelectedKeys: ['1'],
            checkedKeys: [],
            expandedKeys: [],
            selectedKeys: [],
        };
    }

    componentDidMount() {
        this.props.onRef(this)
    }

    updateCheckedKeys = (data) => {
        this.setState({
            checkedKeys: data.checkedKeys,
            checkedList: data.menuCheckStrictly ? ['menuCheckStrictly'] : []
        });
    }

    handleCheckedTreeConnect = () => {
        this.setState({
            checkStrictly: !this.state.checkStrictly
        });
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return; //检查Form表单填写的数据是否满足rules的要求
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            data.menuIds = this.state.checkedKeys
            data.menuCheckStrictly = this.state.checkedList.includes('menuCheckStrictly')
            this.props.onOk(data); //调用父组件给的onOk方法并传入Form的参数。
        })
    };

    onCancel = () => {
        this.props.form.resetFields(); //重置Form表单的内容
        this.props.onCancel() //调用父组件给的方法
    };

    onChange = checkedList => {
        console.log(this.form)
        this.setState({checkedList});
    };

    onCheck = checkedKeys => {
        console.log(checkedKeys)
        let checkedKey = !this.state.checkStrictly ? checkedKeys : checkedKeys.checked;
        this.setState({checkedKeys: checkedKey});
    };

    onSelect = (selectedKeys) => {
        this.setState({selectedKeys});
    };

    onExpand = expandedKeys => {
        this.setState({
            expandedKeys,
            autoExpandParent: false,
        });
    };

    deepTraverSa = (node, nodeList = []) => {
        if (node !== null) {
            nodeList.push(node.key + '')
            let children = node.children
            if (children) {
                for (let i = 0; i < children.length; i++) {
                    this.deepTraverSa(children[i], nodeList)
                }
            }
        }
        return nodeList
    };

    handleCheckedTreeExpand = (val) => {
        const {menuOptions} = this.props;
        const expandedKeys = [];
        menuOptions.forEach(item => {
            expandedKeys.push(this.deepTraverSa(item))
        })
        this.setState({
            expandedKeys: val.target.checked ? expandedKeys.flat() : []
        });
    };

    handleCheckedTreeNodeAll = (val) => {
        const {menuOptions} = this.props;
        const checkedKeys = [];
        menuOptions.forEach(item => {
            checkedKeys.push(this.deepTraverSa(item))
        })
        this.setState({
            checkedKeys: val.target.checked ? checkedKeys.flat() : []
        });
    };

    renderTreeNodes = data =>
        data.map(item => {
            item.key = item.id
            if (item.children) {
                return (
                    <TreeNode title={item.label} key={item.key} dataRef={item}>
                        {this.renderTreeNodes(item.children)}
                    </TreeNode>
                );
            }
            return <TreeNode key={item.key} title={item.label} dataRef={item}/>;
        });

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="login_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="角色名称"
                    >
                        {
                            getFieldDecorator('roleName', {
                                rules: [{required: true, message: '角色名称不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入角色名称" alt="roleName"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="权限字符"
                    >
                        {
                            getFieldDecorator('roleKey', {
                                rules: [{required: true, message: '权限字符不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入权限字符"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="角色顺序"
                    >
                        {
                            getFieldDecorator('roleSort', {
                                initialValue: 0,
                                rules: [{required: true, message: '角色顺序不能为空'}]
                            })(
                                <InputNumber className="from-input-number" min={0} max={9999} allowClear
                                             placeholder=""/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="菜单权限"
                    >
                        {
                            <>
                                <CheckboxGroup value={this.state.checkedList} onChange={this.onChange}>
                                    <Checkbox value="deptExpand"
                                              onChange={this.handleCheckedTreeExpand.bind(this)}>展开/折叠</Checkbox>
                                    <Checkbox value="deptNodeAll"
                                              onChange={this.handleCheckedTreeNodeAll.bind(this)}>全选/全不选</Checkbox>
                                    <Checkbox value="menuCheckStrictly"
                                              onChange={this.handleCheckedTreeConnect.bind(this)}>父子联动</Checkbox>
                                </CheckboxGroup>
                                <Tree
                                    checkable
                                    className="role-tree"
                                    autoExpandParent={this.state.autoExpandParent}
                                    onExpand={this.onExpand}
                                    expandedKeys={this.state.expandedKeys}
                                    onCheck={this.onCheck}
                                    checkedKeys={this.state.checkedKeys}
                                    onSelect={this.onSelect}
                                    selectedKeys={this.state.selectedKeys}
                                    checkStrictly={this.state.checkStrictly}
                                >
                                    {this.renderTreeNodes(this.props.menuOptions)}
                                </Tree>
                            </>
                        }
                    </Form.Item>
                    <Form.Item
                        label="状态"
                    >
                        {
                            getFieldDecorator('status', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择角色状态'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="备注"
                    >
                        {
                            getFieldDecorator('remark')(
                                <TextArea rows={4}  placeholder="请输入备注"/>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
