import React, {Component} from 'react'
import {withRouter} from "react-router-dom";
import {Table, Divider, Button, Pagination, message, Modal, Switch } from 'antd';
import DttForm from '@/components/DttForm';
import {download} from '@/utils/request';
import {addDateRange} from "@/utils/common";
import formItems from './formItems';
import EditModal from './EditModal';
import {listRole, addRole, updateRole, delRole, changeRoleStatus, getRole} from '@/api/system/role';
import { treeselect as menuTreeselect, roleMenuTreeselect } from "@/api/system/menu";

function showTotal(total) {
    return `共 ${total} 条`;
}

class Role extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            ids: [],
            roleList: null,
            total: 0,
            expand: false,
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            },
            visible: false,
            menuOptions: [],
            formData: null,
            modalTitle: '编辑角色',
            columns: [
                {
                    title: '角色编号',
                    dataIndex: 'roleId',
                    width: '120',
                    key: 'roleId',
                },
                {
                    title: '角色名称',
                    dataIndex: 'roleName',
                    width: '150',
                    key: 'roleName',
                },
                {
                    title: '权限字符',
                    dataIndex: 'roleKey',
                    width: '150',
                    key: 'roleKey',
                },
                {
                    title: '显示顺序',
                    dataIndex: 'roleSort',
                    width: '100',
                    key: 'roleSort',
                },
                {
                    title: '状态',
                    key: 'status',
                    width: '100',
                    dataIndex: 'status',
                    render: (text, data) => (
                        <Switch checked={data.status+ '' === '0'} onChange={this.handleStatusChange.bind(this, text, data)} />
                    ),
                },
                {
                    title: '创建时间',
                    key: 'createTime',
                    dataIndex: 'createTime',
                },
                {
                    title: '操作',
                    key: 'action',
                    width: '190px',
                    render: (text) => (
                        <>
                        {text.roleId !== 1 && <span className="dtt-cell-operations">
                            <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                            <Divider type="vertical"/>
                            <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                        </span>}
                       </>
                    ),
                },
            ]
        };
    }

    componentDidMount() {
        this.getList();
    }

    getList() {
        listRole(this.state.queryParams).then(res => {
            this.setState({
                roleList: res.rows,
                total: res.total
            })
        });
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let data = addDateRange(values, values.params)
            let params = {...this.state.queryParams, ...data}
            listRole(params).then(res => {
                this.setState({
                    roleList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    handleAdd = () => {
        menuTreeselect().then(response => {
            this.roleEditModal.updateCheckedKeys({checkedKeys: [], menuCheckStrictly: true})
            this.setState({
                visible: true,
                menuOptions: response.data,
                formData: null,
                modalTitle: '新增角色'
            });
        });
    };

    handleStatusChange = (row, data) => {
        let text = data.status === "1" ? "启用" : "停用";
        Modal.confirm({
            title: '',
            content: '确认要"' + text + '""' + data.roleName + '"角色吗？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: ()=> {
                data.status = data.status === "0" ? "1" : "0";
                changeRoleStatus(data.roleId, data.status).then(()=> {
                    this.getList();
                    message.success(text + "成功");
                })
            },
        });
    }

    onRef = (ref) => {
        this.roleEditModal = ref
    }

    handleUpdate = (row) => {
        const roleId = row.roleId
        const roleMenu = this.getRoleMenuTreeSelect(roleId);
        getRole(roleId).then(response => {
            let data = response.data
            roleMenu.then(res => {
                this.roleEditModal.updateCheckedKeys({checkedKeys: res.checkedKeys, menuCheckStrictly: data.menuCheckStrictly})
                this.setState({
                    visible: true,
                    formData:data,
                    modalTitle: '修改角色'
                });
            });
        });
    }

    getRoleMenuTreeSelect(roleId) {
        return roleMenuTreeselect(roleId).then(response => {
            this.setState({
                menuOptions: response.menus,
            });
            return response;
        });
    }

    handleDelete = (row) => {
        const roleIds = row.roleId || this.state.ids;
        if(roleIds.length === 0) {
            message.warning("请选择要删除的数据！");
            return false
        }
        Modal.confirm({
            title: '',
            content: '是否确认删除角色编号为"' + roleIds + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: ()=> {
                delRole(roleIds).then(()=> {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    };

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleExport = () => {
        download('system/role/export', {
            ...this.state.queryParams
        }, `role_${new Date().getTime()}.xlsx`)
    }

    handleOk = (data) => {
        let methods = data.roleId ? updateRole : addRole;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    render() {
        let {roleList, total, queryParams, visible, modalTitle, menuOptions, formData} = this.state;
        const columns = this.state.columns;
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.roleId)
                })
            },
        };
        return (
            <>
                <div className="dtt-search">
                    <DttForm ref={this.formRef} items={formItems} />
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button icon="plus" type="primary" onClick={this.handleAdd.bind(this)}>新增</Button>
                    <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                    <Button icon="download" onClick={this.handleExport}>导出</Button>
                </div>
                <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={roleList} pagination={false} rowKey='roleId'/>
                <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize} hideOnSinglePage
                            current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                            onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
                <EditModal
                    onRef={this.onRef}
                    visible={visible}
                    title={modalTitle}
                    formData={formData}
                    menuOptions={menuOptions}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />

            </>
        )
    }
}

export default withRouter((Role));
