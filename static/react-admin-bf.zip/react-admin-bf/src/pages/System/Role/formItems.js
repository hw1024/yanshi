import React from 'react'
import {Select, DatePicker} from 'antd'
const {RangePicker} = DatePicker;
import {getDictData} from '@/utils/common'
const Option = Select.Option

const dateFormat = 'YYYY/MM/DD';

const selectTemp = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_normal_disable').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

const rangePickerTemp = (
    <RangePicker format={dateFormat} />
)

export default [
    {
        label: '角色名称',
        key: 'roleName',
        placeholder: '请输入角色名称',
        required: false,
    },
    {
        label: '权限字符',
        key: 'roleKey',
        placeholder: '请输入权限字符',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectTemp,
    },
    {
        label: '创建时间',
        key: 'params',
        required: false,
        component: rangePickerTemp,
    },
]
