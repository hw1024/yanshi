import React from 'react'
import {Select, DatePicker} from 'antd'
import {getDictData} from '@/utils/common'
const {RangePicker} = DatePicker;

const Option = Select.Option

const dateFormat = 'YYYY/MM/DD';

const selectExample = (
    <Select allowClear placeholder='请选择状态'>
        {
            getDictData('sys_common_status').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

const rangePickerTemp = (
    <RangePicker format={dateFormat} />
)

export default [
    {
        label: '登录地址',
        key: 'ipaddr',
        placeholder: '请输入登录地址',
        required: false,
    },
    {
        label: '用户名称',
        placeholder: '请输入用户名称',
        key: 'userName',
        required: false,
    },
    {
        label: '状态',
        key: 'status',
        required: false,
        component: selectExample,
    },
    {
        label: '登录时间',
        key: 'params',
        required: false,
        component: rangePickerTemp,
    },
]
