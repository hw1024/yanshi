import React, {Component} from 'react'
import {Button, Table, Pagination, Modal, message} from 'antd';
import DttForm from '@/components/DttForm';
import formItems from './formItems';
import {addDateRange, filterDictData} from "@/utils/common";
import {listLog, delLoginInfo} from '@/api/system/log';

const columns = [
    {
        title: '访问编号',
        dataIndex: 'infoId',
        key: 'infoId',
    },
    {
        title: '用户名称',
        dataIndex: 'userName',
        key: 'userName',
    },
    {
        title: '登录地址',
        dataIndex: 'ipaddr',
        key: 'ipaddr',
    },
    {
        title: '登录地点',
        dataIndex: 'loginLocation',
        key: 'loginLocation',
    },
    {
        title: '浏览器',
        key: 'browser',
        dataIndex: 'browser',
    },
    {
        title: '操作系统',
        key: 'os',
        dataIndex: 'os',
    },
    {
        title: '登录状态',
        key: 'status',
        dataIndex: 'status',
        render: (text) => (
            <span>{filterDictData('sys_common_status', text)}</span>
        ),
    },
    {
        title: '操作信息',
        key: 'msg',
        dataIndex: 'msg',
    },
    {
        title: '登录日期',
        key: 'loginTime',
        dataIndex: 'loginTime',
    },
];

function showTotal(total) {
    return `共 ${total} 条`;
}

export default class log extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            logList: null,
            total: 0,
            ids: [],
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            }
        };
    }

    componentDidMount() {
        this.getList();
    }

    getList() {
        listLog(this.state.queryParams).then(res => {
            this.setState({
                logList: res.rows,
                loading: false,
                total: res.total
            })
        });
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let data = addDateRange(values, values.params)
            let params = {...this.state.queryParams, ...data}
            listLog(params).then(res => {
                this.setState({
                    logList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleDelete = (row) => {
        const infoIds = row.infoId || this.state.ids;
        console.log(infoIds)
        Modal.confirm({
            title: '',
            content: '是否确认删除访问编号为"' + infoIds + '"的数据项？',
            okText: '确认',
            wrapClassName: 'dtt-confirm',
            cancelText: '取消',
            onOk: ()=> {
                delLoginInfo(infoIds).then(()=> {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    };

    handleExport = () => {
        this.setState({
            sortedInfo: {
                order: 'descend',
                columnKey: 'age',
            },
        });
    };

    render() {
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.infoId)
                })
            },
        };
        let {logList, total, queryParams} = this.state;
        return (
            <>
                <div className="dtt-search">
                    <DttForm ref={this.formRef} items={formItems} />
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                    <Button icon="download" onClick={this.handleExport}>导出</Button>
                </div>
                <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={logList} pagination={false} rowKey='infoId'/>
                <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize} hideOnSinglePage
                            current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                            onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
            </>
        )
    }
}
