import React, {Component} from 'react';
import {Modal, Form, Input, Radio} from 'antd';

const {TextArea} = Input;

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            noticeTitle: Form.createFormField({
                ...props.noticeTitle,
                value: props.formData.noticeTitle
            }),
            status: Form.createFormField({
                ...props.noticeTitle,
                value: props.formData.status
            }),
            noticeType: Form.createFormField({
                ...props.noticeTitle,
                value: props.formData.noticeType
            }),
            noticeContent: Form.createFormField({
                ...props.noticeTitle,
                value: props.formData.noticeContent
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return;
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data);
        })
    };

    onCancel = () => {
        this.props.form.resetFields();
        this.props.onCancel()
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="login_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="公告标题"
                    >
                        {
                            getFieldDecorator('noticeTitle', {
                                rules: [{required: true, message: '公告标题不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入公告标题" alt="noticeTitle"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="公告类型"
                    >
                        {
                            getFieldDecorator('noticeType', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择公告类型'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="状态"
                    >
                        {
                            getFieldDecorator('status', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择状态'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>正常</Radio>
                                    <Radio value={'1'}>停用</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="内容"
                    >
                        {
                            getFieldDecorator('noticeContent')(
                                <TextArea rows={4} placeholder="请输入备注"/>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
