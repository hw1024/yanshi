import React, {Component} from 'react'
import {withRouter} from "react-router-dom";
import {Table, Divider, Button, Pagination, message, Modal } from 'antd';
import DttForm from '@/components/DttForm';
import {download} from '@/utils/request';
import {addDateRange, filterDictData} from "@/utils/common";
import formItems from './formItems';
import EditModal from './EditModal';
import {listNotice, addNotice, updateNotice, delNotice, getNotice} from '@/api/system/notice';

function showTotal(total) {
    return `共 ${total} 条`;
}

class Notice extends Component {
    constructor(props) {
        super(props);
        this.formRef = React.createRef()
        this.state = {
            ids: [],
            noticeList: null,
            total: 0,
            loading: true,
            queryParams: {
                pageNum: 1,
                pageSize: 10
            },
            visible: false,
            formData: null,
            modalTitle: '编辑公告',
            columns: [
                {
                    title: '序号',
                    dataIndex: 'noticeId',
                    width: 124,
                    key: 'noticeId',
                },
                {
                    title: '公告标题',
                    dataIndex: 'noticeTitle',
                    ellipsis: true,
                    key: 'noticeTitle',
                },
                {
                    title: '公告类型',
                    dataIndex: 'noticeType',
                    width: 132,
                    key: 'noticeType',
                    render: (text) => (
                        <span>{filterDictData('sys_notice_type', text)}</span>
                    ),
                },
                {
                    title: '状态',
                    key: 'status',
                    width: 124,
                    dataIndex: 'status',
                    render: (text) => (
                        <span>{filterDictData('sys_notice_status', text)}</span>
                    ),
                },
                {
                    title: '创建者',
                    dataIndex: 'createBy',
                    width: 132,
                    key: 'createBy',
                },
                {
                    title: '创建时间',
                    width: 186,
                    key: 'createTime',
                    dataIndex: 'createTime',
                },
                {
                    title: '操作',
                    key: 'action',
                    width: '190px',
                    render: (text) => (
                        <span className="dtt-cell-operations">
                            <Button type="link" icon="edit" onClick={this.handleUpdate.bind(this, text)}>修改</Button>
                            <Divider type="vertical"/>
                            <Button type="link" icon="delete" onClick={this.handleDelete.bind(this, text)}>删除</Button>
                        </span>
                    ),
                },
            ]
        };
    }

    componentDidMount() {
        this.getList();
    }

    getList() {
        listNotice(this.state.queryParams).then(res => {
            this.setState({
                noticeList: res.rows,
                total: res.total
            })
        });
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.formRef.current.validateFieldsAndScroll((err, values) => {
            if (err) {
                return
            }
            let data = addDateRange(values, values.params)
            let params = {...this.state.queryParams, ...data}
            listNotice(params).then(res => {
                this.setState({
                    noticeList: res.rows,
                    total: res.total
                })
            });
        })
    }

    handleReset = () => {
        this.formRef.current.resetFields();
        this.getList();
    }

    handleAdd = () => {
        this.setState({
            visible: true,
            formData: null,
            modalTitle: '添加公告'
        });
    };

    handleUpdate = (row) => {
        const noticeId = row.noticeId
        getNotice(noticeId).then(response => {
            let data = response.data
            this.setState({
                visible: true,
                formData:data,
                modalTitle: '修改公告'
            });
        });
    }
    handleDelete = (row) => {
        const noticeIds = row.noticeId || this.state.ids;
        if(noticeIds.length === 0) {
            message.warning("请选择要删除的数据！");
            return false
        }
        Modal.confirm({
            title: '',
            content: '是否确认删除公告编号为"' + noticeIds + '"的数据项？',
            cancelText: '取消',
            className: 'dtt-confirm',
            okText: '确认',
            onOk: ()=> {
                delNotice(noticeIds).then(()=> {
                    this.getList();
                    message.success("删除成功");
                })
            },
        });
    };

    onChange = (page, pageSize) => {
        let data = this.state.queryParams;
        data.pageNum = page;
        data.pageSize = pageSize;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    onShowSizeChange = (current, size) => {
        let data = this.state.queryParams;
        data.pageNum = current;
        data.pageSize = size;
        this.setState({
            queryParams: data
        });
        this.getList();
    };

    handleExport = () => {
        download('system/notice/export', {
            ...this.state.queryParams
        }, `notice_${new Date().getTime()}.xlsx`)
    }

    handleOk = (data) => {
        let methods = data.noticeId ? updateNotice : addNotice;
        methods(data).then(response => {
            message.success("操作成功");
            this.setState({
                visible: false,
            });
            this.getList();
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    render() {
        let {noticeList, total, queryParams, visible, modalTitle, formData} = this.state;
        const columns = this.state.columns;
        const rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                this.setState({
                    ids: selectedRows.map(item => item.noticeId)
                })
            },
        };
        return (
            <>
                <div className="dtt-search">
                    <DttForm ref={this.formRef} items={formItems} />
                    <div className="dtt-search-operation">
                        <Button type="primary" onClick={this.handleSearch}>
                            搜索
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                            重置
                        </Button>
                    </div>
                </div>
                <div className="dtt-operations">
                    <Button icon="plus" type="primary" onClick={this.handleAdd.bind(this)}>新增</Button>
                    <Button icon="delete" onClick={this.handleDelete}>删除</Button>
                    <Button icon="download" onClick={this.handleExport}>导出</Button>
                </div>
                <Table className="dtt-table" rowSelection={rowSelection} columns={columns} dataSource={noticeList} pagination={false} rowKey='noticeId'/>
                <Pagination className="dtt-pagination" total={total} pageSize={queryParams.pageSize} hideOnSinglePage
                            current={queryParams.pageNum} showSizeChanger showQuickJumper showTotal={showTotal}
                            onChange={this.onChange} onShowSizeChange={this.onShowSizeChange}/>
                <EditModal
                    visible={visible}
                    title={modalTitle}
                    formData={formData}
                    onOk={(values) => this.handleOk(values)}
                    onCancel={this.handleCancel}
                />

            </>
        )
    }
}

export default withRouter((Notice));
