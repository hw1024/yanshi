import React from 'react'
import {Select} from 'antd'
import {getDictData} from '@/utils/common'
const Option = Select.Option

const selectTemp = (
    <Select allowClear placeholder='请选择类型'>
        {
            getDictData('sys_notice_type').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

export default [
    {
        label: '公告标题',
        key: 'noticeTitle',
        placeholder: '请输入公告标题',
        required: false,
    },
    {
        label: '操作人员',
        key: 'createBy',
        placeholder: '请输入操作人员',
        required: false,
    },
    {
        label: '类型',
        key: 'noticeType',
        required: false,
        component: selectTemp,
    },
]
