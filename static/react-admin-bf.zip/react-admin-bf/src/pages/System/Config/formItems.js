import React from 'react'
import {Select, DatePicker} from 'antd'
import {getDictData} from '@/utils/common'

const {RangePicker} = DatePicker;
const Option = Select.Option
const dateFormat = 'YYYY/MM/DD';

const selectTemp = (
    <Select allowClear placeholder='请选择系统内置'>
        {
            getDictData('sys_yes_no').map((item) => {
                return <Option value={item.dictValue}>{item.dictLabel}</Option>
            })
        }
    </Select>
)

const rangePickerTemp = (
    <RangePicker format={dateFormat}/>
)

export default [
    {
        label: '参数名称',
        key: 'configName',
        placeholder: '请输入参数名称',
        required: false,
    },
    {
        label: '参数键名',
        key: 'configKey',
        placeholder: '请输入参数键名',
        required: false,
    },
    {
        label: '系统内置',
        key: 'configType',
        required: false,
        component: selectTemp,
    },
    {
        label: '登录时间',
        key: 'params',
        required: false,
        component: rangePickerTemp,
    },
]
