import React, {Component} from 'react';
import {Modal, Form, Radio, Input} from 'antd';
const {TextArea} = Input;

function mapPropsToFields(props) {
    if (props.formData) {
        return {
            configName: Form.createFormField({
                ...props.configName,
                value: props.formData.configName
            }),
            configKey: Form.createFormField({
                ...props.configName,
                value: props.formData.configKey
            }),
            configValue: Form.createFormField({
                ...props.configName,
                value: props.formData.configValue
            }),
            configType: Form.createFormField({
                ...props.configName,
                value: props.formData.configType
            }),
            remark: Form.createFormField({
                ...props.configName,
                value: props.formData.remark
            }),
        };
    }
}

class EditModal extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    onOk = () => {
        this.props.form.validateFields((err, values) => {
            if (err) return;
            let data = values
            if (this.props.formData) {
                data = {...this.props.formData, ...data}
            }
            this.props.onOk(data);
        })
    };

    onCancel = () => {
        this.props.form.resetFields();
        this.props.onCancel()
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Modal
                onOk={this.onOk}
                onCancel={this.onCancel}
                visible={this.props.visible}
                title={this.props.title}
            >
                <Form
                    name="login_form"
                    className="ant-form"
                    onSubmit={this.handleSubmit}
                    labelCol={{span: 4}}
                    wrapperCol={{span: 20}}
                    autoComplete="off"
                >
                    <Form.Item
                        label="参数名称"
                    >
                        {
                            getFieldDecorator('configName', {
                                rules: [{required: true, message: '参数名称不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入参数名称" alt="configName"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="参数键名"
                    >
                        {
                            getFieldDecorator('configKey', {
                                rules: [{required: true, message: '参数键名不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入参数键名"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="参数键值"
                    >
                        {
                            getFieldDecorator('configValue', {
                                rules: [{required: true, message: '参数键值不能为空'}]
                            })(
                                <Input allowClear placeholder="请输入参数键值"/>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="系统内置"
                    >
                        {
                            getFieldDecorator('configType', {
                                initialValue: '0',
                                rules: [{required: true, message: '请选择系统内置'}]
                            })(
                                <Radio.Group>
                                    <Radio value={'0'}>是</Radio>
                                    <Radio value={'1'}>否</Radio>
                                </Radio.Group>
                            )
                        }
                    </Form.Item>
                    <Form.Item
                        label="备注"
                    >
                        {
                            getFieldDecorator('remark')(
                                <TextArea rows={4} placeholder="请输入备注"/>
                            )
                        }
                    </Form.Item>
                </Form>
            </Modal>
        )
    }
}

export default Form.create({
    mapPropsToFields: mapPropsToFields
})(EditModal);
