import React from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import RouterAuth from '@/utils/routerComponent';
import Login from '@/pages/Login';
import Page403 from '@/pages/Error/Page403';
import Page404 from '@/pages/Error/Page404';

const routes = [];
const getRouter = () => (
    <Router>
        <Switch>
            <Route path="/login" component={Login}/>
            <Route path="/403" component={Page403}/>
            <Route path="/404" component={Page404}/>
            <RouterAuth config={routes}/>
        </Switch>
    </Router>
);

export default getRouter;
