import Index from '@/pages/Index';

const main = [
    {
        path: '/',
        component: Index,
        routes: []
    }
];

export default main;
