import { LOGIN, LOGOUT, USER_MENU, USER_INFO, DICT_DATA, USER_PERMISSIONS } from '@/redux/types/const';
import { setToken, getToken, removeToken } from '@/utils/auth';

const initState = {
	isLogin: !!getToken(),
	users: localStorage.users ? JSON.parse(localStorage.users) : [{ username: 'admin', password: 'admin' }],
};

export default function reducer(state = initState, action) {
	switch (action.type) {
		case LOGIN:
			setToken(action.data.token);
			return { ...state, isLogin: true};
		case LOGOUT:
			removeToken();
			return { ...state, isLogin: false};
		case USER_MENU:
			return {
				...state,
				"menu": action.data
			}
		case USER_INFO:
			return {
				...state,
				"info": action.data
			}
		case DICT_DATA:
			return {
				...state,
				"dictData": action.data
			}
		case USER_PERMISSIONS:
			return {
				...state,
				"permissions": action.data
			}
		default:
			return state;
	}
}
