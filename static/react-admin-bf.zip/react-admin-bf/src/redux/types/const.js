export const LOGIN = 'LOGIN';

export const LOGOUT = 'LOGOUT';

export const USER_MENU = 'USER_MENU';

export const USER_INFO = 'USER_INFO';

export const DICT_DATA = 'DICT_DATA';

export const USER_PERMISSIONS = 'USER_PERMISSIONS';


