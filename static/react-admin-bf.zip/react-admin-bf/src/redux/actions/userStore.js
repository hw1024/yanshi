import { LOGIN, LOGOUT, USER_MENU, USER_INFO, DICT_DATA, USER_PERMISSIONS } from '@/redux/types/const';

// 登录
export function login(data) {
	return {
		type: LOGIN,
		data
	};
}

// 获取用户信息
export function getUserInfo(data) {
	return {
		type: USER_INFO,
		data
	};
}

// 获取菜单
export function getMenu(data) {
	return {
		type: USER_MENU,
		data
	};
}

// 获取菜单
export function getDictData(data) {
	return {
		type: DICT_DATA,
		data
	};
}


// 获取权限
export function getPermissions(data) {
	return {
		type: USER_PERMISSIONS,
		data
	};
}


// 注销
export function logout() {
	return { type: LOGOUT };
}
