import 'babel-polyfill';
import React from 'react';
import ReactDom from 'react-dom';
import {Provider} from 'react-redux';
import {ConfigProvider} from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import store from './redux/store';
import getRouter from '@/router/router';
import {getToken} from '@/utils/auth';
import {getInfo} from '@/api/passport';
import {listData} from '@/api/system/dict/data';
import {getRouters} from '@/api/menu';
import {USER_MENU, USER_INFO, DICT_DATA, USER_PERMISSIONS} from '@/redux/types/const';
import '@/common/css/reset.scss';
import '@/common/css/ant-reset.scss';
import '@/common/css/index.scss';
import '@/common/font/iconfont.css';

let token = getToken();
if (!!token) {
    getInfo().then((data) => {
        store.dispatch({
            type: USER_INFO,
            data: data.user
        })
        store.dispatch({
            type: USER_PERMISSIONS,
            data: data.permissions
        })
        listData({
            pageNum: 1,
            pageSize: 10000
        }).then((dict) => {
            if (dict.code === 200) {
                store.dispatch({
                    type: DICT_DATA,
                    data: dict.rows
                })
                getRouters().then((res) => {
                    if (res.code === 200) {
                        store.dispatch({
                            type: USER_MENU,
                            data: res.data
                        })
                        ReactDom.render(
                            <Provider store={store}>
                                <ConfigProvider locale={zhCN}>
                                    {getRouter()}
                                </ConfigProvider>
                            </Provider>,
                            document.getElementById('app')
                        );
                    }
                });
            }
        })

    })
} else {
    ReactDom.render(
        <Provider store={store}>
            <ConfigProvider locale={zhCN}>
                {getRouter()}
            </ConfigProvider>
        </Provider>,
        document.getElementById('app')
    );
}
