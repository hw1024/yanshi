import React, {Component} from 'react';
import screenfull from 'screenfull'
import {Icon, message} from 'antd';

class ScreenFull extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isFullscreen: false
        }
    }

    componentDidMount() {
        this.init()
    }

    click() {
        if (!screenfull.isEnabled) {
            message.warning("你的浏览器不支持全屏！");
            return false
        }
        screenfull.toggle()
    }

    init() {
        if (screenfull.isEnabled) {
            screenfull.on('change', this.change)
        }
    }

    change = () => {
        this.setState(() => ({
            isFullscreen: screenfull.isFullscreen
        }));
    }

    componentWillUnmount() {
        if (screenfull.isEnabled) {
            screenfull.off('change', this.change)
        }
    }

    render() {
        return (
            <Icon className="right-menu-item" type={this.state.isFullscreen ? 'fullscreen-exit' : 'fullscreen'} onClick={this.click}/>
        );
    }
}

export default ScreenFull;
