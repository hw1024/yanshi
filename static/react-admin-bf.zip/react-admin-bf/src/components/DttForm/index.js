import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Form, Input, Row, Col } from 'antd'

const FormItem = Form.Item
// 默认的layout
export const defaultLabelColSpan = 6
const defaultFormItemLayout = {
    labelCol: { style: { width: '80px', display: 'inline-block', 'vertical-align': 'inherit' } },
    wrapperCol: { style: {width: 'calc(100% - 80px)', display: 'inline-block'} }
}

// 渲染单个表单项
const renderFormItem = ({ item, layout, getFieldDecorator }) => {
    const { label, key, required, placeholder, component, options = {}, rules } = item
    return (
        <Col span={defaultLabelColSpan} key={key}>
            <FormItem key={key} label={label} {...layout}>
                {getFieldDecorator(key, {
                    ...options,
                    rules: rules || [{ required, message: `${label}为空` }],
                })(component || <Input allowClear placeholder={placeholder}/>)}
            </FormItem>
        </Col>
    )
}

class DttForm extends Component {
    render() {
        const { items, layout, form: { getFieldDecorator } } = this.props
        return (
            <Form>
                <Row gutter={24}>
                    {items.map(item => renderFormItem({ item, layout, getFieldDecorator }))}
                </Row>
            </Form>
        )
    }
}

DttForm.propTypes = {
    items: PropTypes.array.isRequired,
    layout: PropTypes.object,
    form: PropTypes.object.isRequired,
}

DttForm.defaultProps = {
    layout: defaultFormItemLayout,
}

export default Form.create()(DttForm)
