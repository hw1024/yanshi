import React from 'react';
import { Dropdown, Menu } from 'antd';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import store from '@/redux/store';
import { logout } from '@/redux/actions/userStore';
import img from './images/avatar.jpg';
import ScreenFull from "@/components/ScreenFull";
import style from './index.scss';

class HeaderBar extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			userInfo: store.getState().userStore.info,
			avatar: img
		};
	}

	toggle = () => {
		this.props.onToggle();
	}

	logout = () => {
		this.props.logout();
		this.props.history.push({ pathname: '/login' });
	}

	render() {
		let { avatar, userInfo } = this.state;
		let menu = (
			<Menu className={style.menu}>
				<Menu.Item>我的个人主页</Menu.Item>
				<Menu.Item><span onClick={this.logout}>退出登录</span></Menu.Item>
			</Menu>
		);
		return (
			<div className={`${style.headerContent} ${style.clearfix}`}>
				<div className={style.navWrapper}>

				</div>
				<div className={style.userBox}>
					<ScreenFull/>
					<Dropdown overlay={menu}>
						<div>
							<img width="35" height="35" style={{ borderRadius: '100%', verticalAlign: 'middle' }} src={avatar} alt="" />
							<span style={{ marginLeft: '10px' }}>{userInfo.nickName}</span>
						</div>
					</Dropdown>
				</div>
			</div>
		);
	}
}

let mapDispatchToProps = (dispatch) => ({
	logout() {
		dispatch(logout());
	}
});

export default withRouter(connect(null, mapDispatchToProps)(HeaderBar));
