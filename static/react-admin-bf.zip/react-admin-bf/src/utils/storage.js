/**
 * @desc localStorage本地存储-设置
 * @author hw
 * @param {String} [name]    -  存储Key
 * @param {String} [content]    -  存储内容
 * @date 2021-10-25
 */
export const setStore = (name, content) => {
	if (!name) return;
	if (typeof content !== 'string') {
		content = JSON.stringify(content);
	}
	window.localStorage.setItem(name, content);
};

/**
 * @desc localStorage本地存储-获取
 * @author hw
 * @param {String} [name]    -  存储Key
 * @date 2021-10-25
 */
export const getStore = (name) => {
	if (!name) return;
	return window.localStorage.getItem(name);
};

/**
 * @desc localStorage本地存储-删除
 * @author hw
 * @param {String} [name]    -  存储Key
 * @date 2021-10-25
 */
export const removeStore = (name) => {
	if (!name) return;
	window.localStorage.removeItem(name);
};

/**
 * @desc sessionStorage本地存储-设置
 * @author hw
 * @param {String} [name]    -  存储Key
 * @param {String} [content]    -  存储内容
 * @date 2021-10-25
 */
export const setSessionStore = (name, content) => {
	if (!name) return;
	if (typeof content !== 'string') {
		content = JSON.stringify(content);
	}
	window.sessionStorage.setItem(name, content);
};

/**
 * @desc sessionStorage本地存储-获取
 * @author hw
 * @param {String} [name]    -  存储Key
 * @date 2021-10-25
 */
export const getSessionStore = (name) => {
	if (!name) return;
	return window.sessionStorage.getItem(name);
};
