import axios from 'axios';
import {message} from 'antd';
import {getToken, removeToken} from '@/utils/auth';
import {tansParams, blobValidate} from '@/utils/common';
import {saveAs} from 'file-saver';
import config from '@/settings';
import errorCode from '@/utils/errorCode';

axios.defaults.headers['Content-Type'] = 'application/json;charset=utf-8';

const service = axios.create({
	baseURL: 'http://10.173.41.151:8888', 	// axios中请求配置有baseURL选项，表示请求URL公共部分
    timeout: config.timeout	// 超时
});

service.interceptors.request.use((config) => {
    const isToken = (config.headers || {}).isToken === false;
    if (getToken() && !isToken) {
        config.headers.Authorization = `Bearer ${getToken()}`;
    }
    if (config.method === 'get' && config.params) {
        let url = `${config.url}?${tansParams(config.params)}`;
        url = url.slice(0, -1);
        config.params = {};
        config.url = url;
    }
    return config;
}, (error) => {
    Promise.reject(error);
});

// 响应拦截器
service.interceptors.response.use((res) => {
    const code = res.data.code || 200;
    const msg = errorCode[code] || res.data.msg || errorCode.default;
    if (res.request.responseType === 'blob' || res.request.responseType === 'arraybuffer') {
        return res.data;
    }
    if (code === 401) {
        removeToken();
        location.href = '/login';
        return Promise.reject('无效的会话，或者会话已过期，请重新登录。');
    }
    if (code === 500) {
        message.error(msg);
        return Promise.reject(new Error(msg));
    }
    if (code !== 200) {
        message.error(msg);
        return Promise.reject('error');
    }
    return res.data;
},
(error) => {
    let {message} = error;
    if (message + '' === 'Network Error') {
        message = '后端接口连接异常';
    } else if (message.includes('timeout')) {
        message = '系统接口请求超时';
    } else if (message.includes('Request failed with status code')) {
        message = `系统接口${message.substr(message.length - 3)}异常`;
    }
    message.error(message);
    return Promise.reject(error);
});

// 通用下载方法
export function download(url, params, filename) {
    return service.post(url, params, {
        transformRequest: [(params) => {
            return tansParams(params)
        }],
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'blob'
    }).then(async (data) => {
        const isLogin = await blobValidate(data);
        if (isLogin) {
            const blob = new Blob([data])
            saveAs(blob, filename)
        } else {
            message.error('无效的会话，或者会话已过期，请重新登录。');
        }
    }).catch((r) => {
        message.error('下载文件出现错误，请联系管理员！');
    })
}

export default service;
