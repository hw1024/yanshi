import { getStore, setStore, removeStore } from './storage';

const TOKEN_KEY = 'App-Token';
const UserInfo = 'User-Info';

export function getToken() {
	const token = getStore(TOKEN_KEY);
	if (token) {
		return token;
	}
	return false;
}

export function setToken(token) {
	return setStore(TOKEN_KEY, token);
}

export function removeToken() {
	return removeStore(TOKEN_KEY);
}

export function getUserInfo() {
	return getStore(UserInfo) || null;
}

export function setUserInfo(time) {
	return setStore(UserInfo, time);
}

export function removeUserInfo() {
	return removeStore(UserInfo);
}
