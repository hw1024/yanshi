import moment from 'moment'
import store from '@/redux/store';
/**
 * 通用js方法封装处理
 * Copyright (c) 2022
 */

/**
 * 参数处理
 * @param {*} params  参数
 */
export function tansParams(params) {
	let result = '';
	for (const propName of Object.keys(params)) {
		const value = params[propName];
		let part = `${encodeURIComponent(propName)}=`;
		if (value !== null && typeof (value) !== 'undefined') {
			if (typeof value === 'object') {
				for (const key of Object.keys(value)) {
					if (value[key] !== null && typeof (value[key]) !== 'undefined') {
						let params = `${propName}[${key}]`;
						let subPart = `${encodeURIComponent(params)}=`;
						result += `${subPart + encodeURIComponent(value[key])}&`;
					}
				}
			} else {
				result += `${part + encodeURIComponent(value)}&`;
			}
		}
	}
	return result;
}

// 验证是否为blob格式
export async function blobValidate(data) {
	try {
		const text = await data.text();
		JSON.parse(text);
		return false;
	} catch (error) {
		return true;
	}
}

/**
 * 构造树型结构数据
 * @param {*} data 数据源
 * @param {*} id id字段 默认 'id'
 * @param {*} parentId 父节点字段 默认 'parentId'
 * @param {*} children 孩子节点字段 默认 'children'
 */
export function handleTree(data, id, parentId, children) {
	let config = {
		id: id || 'id',
		parentId: parentId || 'parentId',
		childrenList: children || 'children'
	};

	let childrenListMap = {};
	let nodeIds = {};
	let tree = [];

	for (let d of data) {
		let parentId = d[config.parentId];
		if (childrenListMap[parentId] == null) {
			childrenListMap[parentId] = [];
		}
		nodeIds[d[config.id]] = d;
		childrenListMap[parentId].push(d);
	}

	for (let d of data) {
		let parentId = d[config.parentId];
		if (nodeIds[parentId] == null) {
			tree.push(d);
		}
	}

	for (let t of tree) {
		adaptToChildrenList(t);
	}

	function adaptToChildrenList(o) {
		if (childrenListMap[o[config.id]] !== null) {
			o[config.childrenList] = childrenListMap[o[config.id]];
		}
		if (o[config.childrenList]) {
			for (let c of o[config.childrenList]) {
				adaptToChildrenList(c);
			}
		}
	}

	return tree;
}

export function getDictData(type, index) {
	let dictArr = [];
	let dictData = store.getState().userStore.dictData;
	if(dictData && dictData.length > 0) {
		let filDictData = dictData.filter(item => item.dictType === type);
		if (index) {
			filDictData = filDictData.filter(item => item.dictSort > index);
		}
		filDictData.forEach(item => {
			item.value = item.dictValue;
			item.label = item.dictLabel;
			dictArr.push(item);
		})
	}
	return dictArr;
}

export function filterDictData(type, status) {
	let filterDictArr = [];
	let key = '';
	let dictArr = getDictData(type);
	if (typeof status === 'string') {
		dictArr.forEach((item) => {
			if (item.value === status) {
				key = item.label
			}
		});
		return key;
	} else {
		dictArr.forEach(function (item) {
			if (contains(status, item.value)) {
				filterDictArr.push(item)
			}
		});
		return filterDictArr;
	}
}

function contains(arr, obj) {
	if (arr) {
		let i = arr.length;
		while (i--) {
			if (arr[i] === obj) {
				return true;
			}
		}
	}
	return false;
}

// 添加日期范围
export function addDateRange(params, dateRange, propName) {
	let search = params;
	search.params = typeof (search.params) === 'object' && search.params !== null && !Array.isArray(search.params) ? search.params : {};
	dateRange = Array.isArray(dateRange) ? dateRange : [];
	if (typeof (propName) === 'undefined') {
		search.params['beginTime'] = dateRange[0] ? moment(dateRange[0]).format('YYYY-MM-DD') : '';
		search.params['endTime'] = dateRange[1] ? moment(dateRange[1]).format('YYYY-MM-DD') : '';
	} else {
		search.params['begin' + propName] = dateRange[0] ? moment(dateRange[0]).format('YYYY-MM-DD') : '';
		search.params['end' + propName] = dateRange[1] ? moment(dateRange[1]).format('YYYY-MM-DD') : '';
	}
	return search;
}

// 转换字符串，undefined,null等转化为""
export function parseStrEmpty(str) {
	if (!str || str == "undefined" || str == "null") {
		return "";
	}
	return str;
}
