/**
 * @desc cookie本地存储-设置
 * @author hw
 * @param {String} [name]    -  存储Key
 * @param {String} [value]    -  存储内容
 * @param {Number} [expiresDays]    -  过期其时间
 * @date 2021-10-25
 */
export function setCookie(name, value, expiresDays = 1) {
    let date = new Date();
    date.setTime(date.getTime() + expiresDays * 24 * 3600 * 1000);
    let expiresStr = `expires=${date.toGMTString()};`;
    document.cookie = `${name}=${escape(value)};${expiresStr}`;
}

/**
 * @desc cookie本地存储-获取
 * @author hw
 * @param {String} [name]    -  存储Key
 * @date 2021-10-25
 */
export function getCookie(name) {
    let cookies = document.cookie.replace(/[ ]/g, '');
    let resArr = cookies.split(';');
    let res = '';
    for (let i = 0, len = resArr.length; i < len; i++) {
        let arr = resArr[i].split('=');
        if (arr[0] === name) {
            res = arr[1];
            break;
        }
    }
    return unescape(res);
}

/**
 * @desc cookie本地存储-删除
 * @author hw
 * @param {String} [name]    -  存储Key
 * @date 2021-10-25
 */
export function removeCookie(name) {
    const exp = new Date();
    exp.setTime(exp.getTime() - 1);
    const cVal = getCookie(name);
    if (cVal != null) {
        document.cookie = `${name}=${cVal};expires=${exp.toGMTString()}`;
    }
}
